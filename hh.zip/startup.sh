#!/bin/bash
echo "[$(date)] Running startup tasks..."

# echo "Current user: $(whoami)"
# echo "$CONFIG_DIR"

# Выполняем цепочку
/bin/bash /app/hh-run-all.sh refresh-token
/bin/bash /app/hh-run-all.sh update-resumes
/bin/sh /app/apply_with_notify.sh

echo "[$(date)] Startup tasks finished."
