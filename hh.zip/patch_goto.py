#!/usr/bin/env python3
"""Patch installed hh_applicant_tool: relax the OAuth page load condition.

authorize.py navigates to hh.ru/oauth/authorize with wait_until="load", which
waits for every subresource — analytics and ad scripts included. When one of
them hangs (common from a server IP), the `load` event never fires and the
whole authorization dies with `Page.goto: Timeout 60000ms exceeded`, even
though the login form is on screen within a second.

`domcontentloaded` fires as soon as the HTML is parsed. Nothing is lost:
right after goto the tool waits for the login input selector anyway, which is
the real readiness check.

Idempotent; never fails the build (exits 0 on any issue).
"""
import re
import sys

OLD = 'wait_until="load"'
NEW = 'wait_until="domcontentloaded"'

try:
    from hh_applicant_tool.operations import authorize
    path = authorize.__file__
except Exception as e:
    print(f"patch_goto: cannot import authorize.py: {e}")
    sys.exit(0)

try:
    with open(path, encoding="utf-8") as f:
        src = f.read()
except Exception as e:
    print(f"patch_goto: cannot read {path}: {e}")
    sys.exit(0)

if NEW in src:
    print("patch_goto: already patched, skipping")
    sys.exit(0)

# Правим только ожидания рядом с page.goto(...), чтобы не задеть возможные
# другие места, где "load" осмыслен.
pattern = re.compile(r"(page\.goto\((?:[^()]|\([^()]*\))*?)" + re.escape(OLD), re.S)
patched, count = pattern.subn(lambda m: m.group(1) + NEW, src)

if not count:
    print(f"patch_goto: {OLD} not found near page.goto(), skipping")
    sys.exit(0)

try:
    with open(path, "w", encoding="utf-8") as f:
        f.write(patched)
except Exception as e:
    print(f"patch_goto: cannot write {path}: {e}")
    sys.exit(0)

print(f"patch_goto: patched {path} ({count} occurrence(s))")
