#!/usr/bin/env python3
"""Builds apply-vacancies command from the active profile and execs it.

Doing this in Python (not bash) avoids word-splitting problems with
search queries that contain spaces, quotes, OR/NOT operators and parens.
"""
import os
import sys

sys.path.insert(0, "/app")
import profiles_lib

LETTERS_DIR = "/app/letters"


def main():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        print("ERROR: no active profile", file=sys.stderr)
        return 1

    hh_account = profile.get("hh_account", "main")
    search = profile.get("search", "")
    letter = profile.get("letter", "letter_default.txt")
    area = str(profile.get("area", 113))
    excluded = profile.get("excluded_filter", "")
    resume_id = (profile.get("resume_id") or "").strip()

    display = profile.get("display_name") or pid
    print(f"Profile: {display} (HH account: {hh_account})")
    print(f"Search: {search}")
    print(f"Letter: {letter}, Area: {area}")

    letter_path = os.path.join(LETTERS_DIR, os.path.basename(letter))
    if not os.path.isfile(letter_path):
        print(f"ERROR: letter file not found: {letter_path}", file=sys.stderr)
        return 1

    if not search.strip():
        print("ERROR: empty search query", file=sys.stderr)
        return 1

    # Каждый аргумент — отдельный элемент списка, никакого word-splitting.
    args = [
        "hh-applicant-tool",
        "--profile", hh_account,
        "apply-vacancies",
        "-L", letter_path,
        "--force-message",
        "--search", search,
        "--area", area,
    ]

    if resume_id:
        args.extend(["--resume-id", resume_id])

    # excluded_filter: утилита принимает ОДНУ строку через запятую
    # (как в исходной рабочей версии: --excluded-filter "a,b,c").
    excluded = (excluded or "").strip()
    if excluded:
        args.extend(["--excluded-filter", excluded])

    print(f"Exec: {args}", flush=True)
    # Заменяем текущий процесс утилитой (как exec в bash)
    os.execvp(args[0], args)


if __name__ == "__main__":
    sys.exit(main())
