# HH Applicant Bot

Automated mass-application system for hh.ru vacancies, managed via a Telegram bot.

Built on top of the [`s3rgeym/hh-applicant-tool`](https://github.com/s3rgeym/hh-applicant-tool) utility. Runs in three Docker containers, operates on a cron schedule, and sends real-time notifications about every application to Telegram.

---

## Features

- **Automatic application sending** every hour from 8:00 to 21:00 MSK, based on a configurable search query
- **Cover letter with randomization** — every application gets a unique text generated from variants in curly braces
- **Real-time notifications** in Telegram for every sent application (vacancy title, employer, link)
- **Run summary** after each batch: sent / attempts / errors
- **Telegram bot for management**:
  - View status, statistics, recent applications, application statuses on HH
  - Edit the letter and search query directly from the chat
  - Pause/resume with active-run termination
  - Inline menu with button navigation
- **HH daily limit detection** (200/day) — the bot detects when HH returns "limit reached"
- **Automatic log rotation** for the utility, once a day
- **All times in MSK** (containers run with TZ=Europe/Moscow)

---

## Architecture

Three Docker containers sharing a single image:

| Service | Purpose | User |
|---------|---------|------|
| `hh_applicant_tool` | Main container: cron, `hh-applicant-tool` utility, Playwright | root (for cron) |
| `hh_tg_bot` | Telegram bot for management | docker (UID 1000) |
| `hh_tg_watcher` | Daemon parsing `config/log.txt` in real time, sending notifications | docker (UID 1000) |

A shared volume `.:/app` means all three containers see the same project filesystem. Changes to `.py` and `.sh` files are picked up on the fly without rebuilding.

### Data flow

```
                          ┌─────────────────────┐
                          │ crontab (8-21 MSK)  │
                          └──────────┬──────────┘
                                     │ every hour
                                     ▼
              ┌──────────────────────────────────────┐
              │       apply_with_notify.sh           │
              │  • Checks .paused                    │
              │  • Launches apply-vacancies.sh       │
              │  • Watcher-thread tracks the pause   │
              └─────────────────┬────────────────────┘
                                │
                ┌───────────────┴───────────────┐
                ▼                               ▼
   ┌─────────────────────┐         ┌─────────────────────────┐
   │ hh-applicant-tool   │         │ _summary.py             │
   │ apply-vacancies     │         │ (summary to TG)         │
   │                     │         └─────────────────────────┘
   │ Writes to:          │
   │ config/log.txt      │
   └──────────┬──────────┘
              │ lines: 201 POST .../negotiations
              ▼
   ┌─────────────────────┐
   │ tg_watcher.py       │   ──→  Telegram: ✅ Application sent
   │ (tail -F log.txt)   │        💼 <title>
   │                     │        🔗 <link>
   └─────────────────────┘
```

---

## Project files

```
hh/
├── Dockerfile              Image build (Python 3.11 + Chromium + utility)
├── docker-compose.yml      Three-service definition
├── crontab                 Task schedule (hours in MSK)
├── startup.sh              Script run at @reboot
│
├── profiles.json           Profile config (accounts + queries + letters)
├── profiles_lib.py         Shared profile load/save/switch library
│
├── apply-vacancies.sh      Reads active profile, runs apply-vacancies
├── apply_with_notify.sh    Wrapper with pause logic and summary
├── _summary.py             Sends run summary to Telegram (per active profile)
├── auth_helper.py          Bridges utility's auth stdin/stdout to the bot
│
├── letters/                Cover letter files
│   └── letter_default.txt
│
├── tg_bot.py               Telegram bot (profiles, control, statistics, menu, auth)
├── tg_watcher.py           Real-time daemon (all accounts) + token-expiry alerts
├── tg_notifier.py          Alternative detailed-card notifier (not used by default)
│
├── config/                 Created by the utility on first run
│   ├── <account>/          Per-HH-account dir (main, second, ...)
│   │   ├── config.json     HH tokens for this account
│   │   ├── data            Utility SQLite DB
│   │   └── log.txt         Utility log for this account
│   ├── .paused             Pause flag (created by /pause)
│   ├── .apply.pid          Active run PID
│   ├── .watcher_state.json Watcher state
│   └── .auth_*             Auth-dialog comm files (transient)
│
├── .gitignore
├── .dockerignore
└── .env                    TG_BOT_TOKEN and TG_CHAT_ID
```

---

## Deployment

### Requirements

- Linux VPS (Debian 12+ / Ubuntu 22+)
- Docker 20+ with docker compose v2
- Telegram access (for the bot)
- An hh.ru account with a resume

### First-time installation

```bash
# 1. Prepare the directory
mkdir -p ~/projects/hh
cd ~/projects/hh

# 2. Unpack the archive
unzip hh.zip
mv hh/* . && mv hh/.* . 2>/dev/null; rmdir hh

# 3. Configure .env
cat > .env << EOF
TG_BOT_TOKEN=YOUR_TOKEN_FROM_BOTFATHER
TG_CHAT_ID=YOUR_TELEGRAM_USER_ID
EOF
chmod 600 .env

# 4. Fix file ownership (the bot runs as user 1000)
chown -R 1000:1000 .

# 5. Build the image (~10-15 minutes — pulls Chromium ~300 MB)
docker compose build

# 6. Start
docker compose up -d

# 7. Authenticate with HH (one-time)
docker compose exec -u docker hh_applicant_tool \
  hh-applicant-tool -vv auth -k

# Enter your email/phone, receive a code via SMS/email, enter the code.
# Tokens will be saved in config/config.json

# 8. Verify
docker compose exec -u docker hh_applicant_tool hh-applicant-tool whoami
# Should print your HH ID and name
```

### Getting TG_CHAT_ID

Message [@userinfobot](https://t.me/userinfobot) on Telegram — it will return your numeric ID.

### Creating a Telegram bot

1. Message [@BotFather](https://t.me/BotFather) and use `/newbot`
2. Pick a name and username for your bot
3. Get a token like `123456:ABC-DEF...`
4. Put the token in `.env` as `TG_BOT_TOKEN`

### Updating

When you receive a new archive version:

```bash
cd ~/projects/hh
unzip -o hh.zip
mv hh/* . && mv hh/.* . 2>/dev/null; rmdir hh
chown -R 1000:1000 .

# Restart (build is NOT required if only .py/.sh files changed)
docker compose restart

# Rebuild is required if Dockerfile or crontab changed:
docker compose down && docker compose build && docker compose up -d
```

---

## Bot commands

### Main menu (recommended)

```
/menu
```

Opens a button-based interface showing the active profile and four sections: "📊 View", "🎛 Control", "👤 Profile", "❓ Help". The menu updates in place when a button is tapped.

### Text commands

| Command | Description |
|---------|-------------|
| `/menu` | Open the button menu |
| `/help` | List all commands |
| **View** | |
| `/status` | Current system status of the active profile, HH limit |
| `/next` | When the next cron run is, slot availability forecast |
| `/stats_today` | Today's application stats |
| `/stats` | Full statistics, broken down by day |
| `/recent` | Last 10 applications with vacancy titles and links |
| `/statuses` | Application statuses on HH (rejections, invitations, offers) |
| `/log` | Last 30 lines of the active account's log |
| **Control** | |
| `/pause` | Pause sending (creates `.paused`, kills the active run) |
| `/resume` | Resume sending |
| `/run` | Run a batch right now for the active profile |
| `/cleanup` | Delete rejections via `clear-negotiations -d` |
| **Profile** | |
| `/profiles` | List all profiles, active one marked |
| `/profile_add` | Create a new profile (3-step dialog) |
| `/profile_rename` | Rename the active profile |
| `/letter` | Show the active profile's letter |
| `/letter_set` | Change the active profile's letter |
| `/search` | Show the active profile's search query |
| `/search_set` | Change the active profile's search query |
| `/auth` | Authenticate the active profile's HH account (interactive in TG) |
| `/cancel` | Cancel pending input or auth |

Only a short list is registered in the Telegram "/" autocomplete: `/menu /run /status /stats_today /next /pause /resume`. The rest still work, they're just not shown in the popup.

---

## Profiles (multi-account, multi-query)

A **profile** bundles an HH account + a search query + a cover letter + a region. You can have several profiles, possibly across multiple HH accounts. Cron and `/run` operate on the **active** profile; switching is manual via the bot.

Config lives in `profiles.json`:

```json
{
  "active": "profile_1",
  "profiles": {
    "profile_1": {
      "display_name": "DevOps",
      "hh_account": "main",
      "search": "(devops OR sre) AND linux",
      "letter": "letter_default.txt",
      "area": 113,
      "excluded_filter": "1с,продажи"
    },
    "profile_2": {
      "display_name": "Sysadmin",
      "hh_account": "main",
      "search": "Системный администратор",
      "letter": "letter_sysadmin.txt",
      "area": 1
    }
  }
}
```

- `display_name` — shown in the bot, editable via `/profile_rename`. Internal IDs (`profile_1`, ...) are auto-generated and never shown.
- `hh_account` — which HH account directory under `config/<account>/`. Profiles sharing an account share its 200/day limit (HH counts per account).
- `letter` — file name under `letters/`. Multiple profiles can reuse one letter.

Switch profiles via `/menu → 👤 Profile → ⟳ Switch profile`. The next cron run uses the new active profile automatically — no restart needed.

### Authenticating a second HH account

Create a profile with a new `hh_account` (e.g. `second`), switch to it, then `/menu → 👤 Profile → 🔑 Authenticate` (or `/auth`). The bot runs the interactive auth flow through Telegram: it relays the utility's prompts to you and forwards your replies (phone, SMS code) back. Each step has a 3-minute timeout; `/cancel` aborts.

This works because a helper process (`auth_helper.py`) runs inside the `hh_applicant_tool` container, bridging the utility's stdin/stdout to the bot through files in `config/`.

---

## Schedule (crontab)

| Time (MSK) | Task |
|------------|------|
| `0 8-21 * * *` | Send applications for the active profile every hour 8–21 (+ 1–5 min random delay) |
| `0 */4 * * *` | Refresh resumes every 4 hours |
| `0 * * * *` | Refresh HH access token |
| `0 3 * * *` | Clean rejections from the local DB |
| `30 3 * * *` | Rotate the log (keep last 5 MB if file > 5 MB) |

Note: `refresh-token`, `update-resumes`, and `clear-negotiations` in cron run without `--profile`, so they target the default HH account. The per-profile `--profile` routing applies to `apply-vacancies` (the active profile). For multiple accounts, the access token is also refreshed in-flight during each apply run.

To change the schedule, edit `crontab`, then `docker compose down && docker compose build && docker compose up -d` (rebuild required — crontab is baked into the image).

---

## Search configuration

In `apply-vacancies.sh` — the `SEARCH` variable uses HH's query language.

Additional parameters:

| Parameter | Value | Purpose |
|-----------|-------|---------|
| `-L /app/letter.txt` | Path to letter | Cover letter |
| `--force-message` | flag | Always send a letter on every application |
| `--search "$SEARCH"` | Query | HH search string |
| `--excluded-filter "..."` | Comma-separated | Words that exclude a vacancy from results |
| `--area 113` | Region ID | 113=Russia, 1=Moscow, 2=St. Petersburg, 40=Kazakhstan, 16=Belarus |

For more on composing the letter and the query — see `hh_regulations.md` (provided separately).

---

## Cover letter

`letter.txt` — a plain text file. Supports:

**Placeholders** (substituted by the utility):

| Placeholder | Meaning |
|-------------|---------|
| `%(vacancy_name)s` | Vacancy title |
| `%(employer_name)s` | Company name |
| `%(first_name)s` | Applicant's first name |
| `%(last_name)s` | Last name |

**Randomization** `{variant1|variant2|variant3}` — one is picked at random per send. Used to bypass HH spam filters. A minimum of 4 randomization points per letter is recommended.

Edited via the bot: `/letter_set` → send the new text as the next message.

---

## Managing via the Telegram bot

### Editing the letter

```
/letter
→ Bot shows the current text

/letter_set
→ Bot: "Send the new text as one message"

<you send the new text>
→ Bot: "✅ Letter updated (1234 chars)"
```

Validation: length 50-5000 characters.

### Editing the search query

```
/search
→ Bot shows the current query

/search_set
→ Bot: "Send the new query as one message"

<you send the new query>
→ Bot: "✅ Search query updated (543 chars)"
```

Validation:
- Length 5-3000 characters
- **Single quotes `'` are forbidden** (they break the bash string); use double quotes `"`

### Pause/resume

```
/pause
→ .paused is created, active run is killed within 2-5 seconds
→ Watcher stops sending notifications

/resume
→ .paused is removed, everything returns to normal
```

---

## HH limits and behavior on hitting them

HH limits each account to **200 applications per day**. The window is rolling (roughly 24 hours from the first application).

When the limit is reached, HH returns `400 POST /negotiations` with the message "Application limit reached". The utility detects this and stops trying.

The bot **detects this automatically** — `/status` and `/next` will show:

```
🛑 HH limit reached (recorded 2026-05-25 18:28 MSK)
New applications will not be sent until the window resets (~24h).
```

Once the window resets (typically the following morning), cron will automatically resume sending.

---

## Real-time notifications

For each successful application, the watcher sends to Telegram:

```
✅ Application sent
💼 Linux System Administrator — OOO Tekhnologii
🔗 https://hh.ru/vacancy/133003715
```

If the HH API does not return a vacancy name — fallback to `Vacancy 133003715`.

At the end of each run, a summary arrives:

```
✅ apply-vacancies run
🕒 2026-05-25 08:45 MSK
📤 Sent: 18
🔍 Attempts: 23
🐛 Errors: 0
Exit: 0
```

Summary icons:
- ✅ — completed successfully
- ⚠️ — there were errors but some applications got through
- 🛑 — hit the HH daily limit
- ❌ — critical error

---

## Troubleshooting

### Containers do not start

```bash
docker compose ps
docker compose logs --tail=50
```

### The bot does not respond

```bash
docker compose logs --tail=30 hh_tg_bot
```

Common issues:
- `TG_BOT_TOKEN` is wrong → check `.env`
- `TG_CHAT_ID` does not match your ID → the bot sees messages but ignores them
- Permission denied on `apply-vacancies.sh` → `chown -R 1000:1000 .`

### Notifications do not arrive

```bash
docker compose logs --tail=30 hh_tg_watcher
```

If you see `HH API failed for vacancy X: ...` in the watcher log — the HH token has expired or API access is broken. Check:

```bash
docker compose exec -u docker hh_applicant_tool hh-applicant-tool whoami
```

If it fails — re-authenticate:

```bash
docker compose exec -u docker hh_applicant_tool hh-applicant-tool -vv auth -k
```

### Cron is not working

```bash
docker compose exec hh_applicant_tool crontab -u docker -l
```

It should print the tasks from `crontab`. If empty — rebuild the image (`docker compose build`).

```bash
docker compose logs --tail=50 hh_applicant_tool
```

Shows the cron log.

### No applications go out (Sent: 0)

Possible causes (in order of frequency):

1. **HH daily limit reached** — check `/status`, should show 🛑
2. **Already applied to all matching vacancies** — normal, wait for new postings
3. **Search query returns zero results** — open the query on hh.ru in the browser to verify
4. **Refresh token is broken** — manually run `docker compose exec -u docker hh_applicant_tool hh-applicant-tool refresh-token`
5. **HH has temporarily banned the account** — pause for a day, then resume at lower frequency

---

## Known limitations

- **`/letter_set` and `/search_set` keep state in process memory.** If the bot restarts between the prompt and your reply, you have to start over.
- **`/pause` does not undo applications already sent.** Once HH has accepted an application, the bot cannot withdraw it.
- **The utility's local DB is not populated during `apply-vacancies`.** This is the utility's own behavior. That's why the bot's statistics are read **from the log**, not from the DB. The DB is populated only by `refresh-token` and similar commands.
- **The search query must not contain single quotes `'`** — the bot will reject it.
- **HH changes its API occasionally.** If things suddenly stop working with no visible reason — check for utility updates:
  ```bash
  docker compose exec hh_applicant_tool pip install -U hh-applicant-tool
  docker compose restart
  ```

---

## Security

- `.env` with tokens has mode `600` (only root can read)
- `TG_CHAT_ID` whitelist — the bot only responds to messages from a single chat
- HH tokens are stored in `config/config.json` — this file **is not committed to git** (`.gitignore`)
- All HTTP requests to HH go through the standard stack, unmodified (anti-detection comes from letter randomization and request delays)

---

## Crontab structure

```cron
@reboot                /bin/bash /app/startup.sh
0 */4 * * *            hh-applicant-tool update-resumes  # refresh resumes
0 8-21 * * *           /bin/bash /app/apply_with_notify.sh  # send applications
0 * * * *              hh-applicant-tool refresh-token  # refresh token
0 3 * * *              hh-applicant-tool clear-negotiations -d  # clean rejections
30 3 * * *             rotate log.txt  # if > 5 MB
```

---

## License and dependencies

The `hh-applicant-tool` utility is distributed under a Limited Non-Commercial License — it **cannot be modified or redistributed in modified form**. This project uses it as-is from PyPI, without modifications.

The rest of this project's code (Dockerfile, scripts, bot) is free to use.

---

## Context

This project was built iteratively, through a series of edits and live tests on a production VPS doing real application sending.

---

## Acknowledgements

A huge thank you to **[s3rgeym](https://github.com/s3rgeym)** — the author of the original [`hh-applicant-tool`](https://github.com/s3rgeym/hh-applicant-tool). Without their work, this project would not exist in any form.

The utility does the heavy lifting: authentication with hh.ru, browser automation via Playwright, the HH API client, the matching logic for vacancies, sending applications, refreshing tokens, managing resumes — every part of the core mechanism that makes mass-applying actually work. The author wrestled with hh.ru's authentication flow, reverse-engineered the API, kept up with HH's changes, and packaged it all into a clean CLI tool. That's an enormous amount of careful, unglamorous work, and it shows in how solid the utility is in real-world use.

What this project adds on top is a different question. It wraps the utility into a self-hosted Docker stack with cron scheduling, builds a Telegram bot for hands-off management from a phone, parses the utility's log in real time to deliver per-application notifications, handles pause/resume cleanly across containers, and integrates monitoring of HH's daily limit. None of these would matter without a reliable foundation underneath — and the foundation is entirely the author's contribution.

The author has explicitly stated in their repository that they are not fond of forks. I want to be clear that **this project does not fork the utility**. The utility is installed from PyPI as-is, used as a black-box dependency, and never modified. There are no patches, no monkey-patches, no redistribution of modified source. If you want to use this project, you install the utility the same way the author intended — through `pip install hh-applicant-tool`. The author's license terms are respected fully.

If this project is useful to you, please **star the original utility's repository** as well — the credit belongs there first. And if you find bugs in vacancy sending, authentication, or anything touching the HH API itself, the right place to report them is the upstream [s3rgeym/hh-applicant-tool](https://github.com/s3rgeym/hh-applicant-tool) issue tracker — those are the author's domain, not this project's.

Thank you, s3rgeym. This is genuinely useful work, and a lot of people are quietly getting jobs because of it.
