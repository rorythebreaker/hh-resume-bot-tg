#!/usr/bin/env python3
"""
Парсит лог hh-applicant-tool (log.txt) и шлёт в TG детали реально
отправленных откликов (POST 201 на /negotiations).
"""
import os
import sys
import re
import html
import json
import time
import urllib.request
import urllib.parse
from pathlib import Path

TG_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
TG_CHAT = os.environ.get("TG_CHAT_ID", "")
CONFIG_DIR = Path(os.environ.get("CONFIG_DIR", "/app/config"))
PROFILE_ID = os.environ.get("HH_PROFILE_ID", "")

LOG_FILE = CONFIG_DIR / "log.txt"
STATE_FILE = CONFIG_DIR / ".notifier_state.json"


def tg_send(text):
    if not TG_TOKEN or not TG_CHAT:
        return False
    data = urllib.parse.urlencode({
        "chat_id": TG_CHAT,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": "true",
    }).encode()
    try:
        urllib.request.urlopen(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            data=data, timeout=15).read()
        return True
    except Exception as e:
        print(f"TG send failed: {e}", file=sys.stderr)
        return False


def hh_get(path):
    try:
        from hh_applicant_tool import HHApplicantTool
        args = ["--profile", PROFILE_ID] if PROFILE_ID else []
        return HHApplicantTool(args).api_client.get(path) or {}
    except Exception as e:
        print(f"HH API failed ({path}): {e}", file=sys.stderr)
        return {}


def fmt_salary(s):
    if not s:
        return "не указана"
    frm = s.get("from")
    to = s.get("to")
    cur = s.get("currency", "")
    gross = s.get("gross")
    parts = []
    if frm:
        parts.append(f"от {int(frm):,}".replace(",", " "))
    if to:
        parts.append(f"до {int(to):,}".replace(",", " "))
    if not parts:
        return "не указана"
    txt = " ".join(parts)
    if cur:
        txt += f" {cur}"
    if gross:
        txt += " (gross)"
    return txt


def fmt_work_format(vac):
    wf = vac.get("work_format") or []
    if isinstance(wf, list) and wf:
        names = [x.get("name", "") for x in wf if isinstance(x, dict) and x.get("name")]
        if names:
            return ", ".join(names)
    sch = (vac.get("schedule") or {}).get("name")
    return sch or "—"


def clean_html(s):
    s = re.sub(r"<[^>]+>", " ", s or "")
    s = html.unescape(s)
    return re.sub(r"\s+", " ", s).strip()


def load_state():
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return {"sent_vacancies": [], "last_pos": 0}


def save_state(state):
    try:
        STATE_FILE.write_text(json.dumps(state))
    except Exception as e:
        print(f"state save failed: {e}", file=sys.stderr)


def extract_new_applies():
    """Из лога вытаскиваем vacancy_id всех успешных POST 201 на /negotiations
    с момента последнего запуска нотификатора."""
    if not LOG_FILE.exists():
        return []

    state = load_state()
    last_pos = state.get("last_pos", 0)
    already_sent = set(state.get("sent_vacancies", []))

    try:
        size = LOG_FILE.stat().st_size
        # Если лог уменьшился (ротация) — читаем с начала
        if size < last_pos:
            last_pos = 0
        with LOG_FILE.open("r", errors="ignore") as f:
            f.seek(last_pos)
            chunk = f.read()
            new_pos = f.tell()
    except Exception as e:
        print(f"log read failed: {e}", file=sys.stderr)
        return []

    # Шаблон: успешный POST на /negotiations с vacancy_id
    # Пример строки: 201 POST https://api.hh.ru/negotiations with params: {'resume_id': '...', 'vacancy_id': '133416137', 'message': '...'}
    pattern = re.compile(
        r"201 POST https://api\.hh\.ru/negotiations with params: \{[^}]*'vacancy_id':\s*'(\d+)'",
        re.MULTILINE
    )
    vacancy_ids = []
    for m in pattern.finditer(chunk):
        vid = m.group(1)
        if vid not in already_sent and vid not in vacancy_ids:
            vacancy_ids.append(vid)

    # Сохраняем новое состояние
    state["last_pos"] = new_pos
    state["sent_vacancies"] = list(already_sent | set(vacancy_ids))[-1000:]  # храним только последние 1000
    save_state(state)

    return vacancy_ids


def main():
    if not (TG_TOKEN and TG_CHAT):
        print("TG credentials missing", file=sys.stderr)
        return

    vacancy_ids = extract_new_applies()
    if not vacancy_ids:
        print("No new applies to notify")
        return

    print(f"Notifying about {len(vacancy_ids)} new applies")

    for vid in vacancy_ids:
        vac = hh_get(f"/vacancies/{vid}")
        if not vac:
            tg_send(f"✅ Новый отклик\n🔗 https://hh.ru/vacancy/{vid}\n(детали недоступны)")
            time.sleep(0.5)
            continue

        name = vac.get("name") or "—"
        employer = (vac.get("employer") or {}).get("name") or "—"
        area = (vac.get("area") or {}).get("name") or "—"
        salary = fmt_salary(vac.get("salary") or vac.get("salary_range") or {})
        wf = fmt_work_format(vac)
        url = vac.get("alternate_url") or f"https://hh.ru/vacancy/{vid}"
        exp = (vac.get("experience") or {}).get("name") or ""

        desc = clean_html(vac.get("description", ""))
        if len(desc) > 700:
            desc = desc[:700].rsplit(" ", 1)[0] + "…"

        text = (
            f"✅ <b>Новый отклик</b>\n"
            f"💼 <b>{html.escape(name)}</b>\n"
            f"🏢 {html.escape(employer)}\n"
            f"📍 {html.escape(area)}   🗓 {html.escape(wf)}\n"
            f"💰 {html.escape(salary)}"
        )
        if exp:
            text += f"\n🧰 Опыт: {html.escape(exp)}"
        text += f"\n🔗 <a href=\"{url}\">Открыть на hh.ru</a>"
        if desc:
            text += f"\n\n<i>{html.escape(desc)}</i>"

        tg_send(text)
        time.sleep(0.3)  # не флудим Telegram


if __name__ == "__main__":
    main()
