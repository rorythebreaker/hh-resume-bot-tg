#!/bin/bash
set -u

PAUSE_FLAG=/app/config/.paused
PID_FILE=/app/config/.apply.pid

# Проверка паузы перед стартом
if [ -f "$PAUSE_FLAG" ]; then
    echo "[$(date)] Paused (flag exists: $PAUSE_FLAG), skipping apply"
    exit 0
fi

LOG=$(mktemp)
RUN_START=$(date '+%Y-%m-%d %H:%M:%S')

# Очистка при выходе
cleanup() {
    if [ -n "${WATCHER_PID:-}" ]; then
        kill "$WATCHER_PID" 2>/dev/null || true
    fi
    rm -f "$PID_FILE" "$LOG"
}
trap cleanup EXIT INT TERM

# Запускаем apply-vacancies.sh в фоне
/bin/bash /app/apply-vacancies.sh 2>&1 | tee "$LOG" &
APPLY_PID=$!
echo "$APPLY_PID" > "$PID_FILE"

# Watcher-thread, который смотрит за pause-флагом
(
    while kill -0 "$APPLY_PID" 2>/dev/null; do
        if [ -f "$PAUSE_FLAG" ]; then
            echo "[$(date)] Pause flag detected, killing apply process tree" >&2
            # Убиваем всё дерево, потом сам процесс
            pkill -TERM -P "$APPLY_PID" 2>/dev/null || true
            kill -TERM "$APPLY_PID" 2>/dev/null || true
            sleep 2
            pkill -KILL -P "$APPLY_PID" 2>/dev/null || true
            kill -KILL "$APPLY_PID" 2>/dev/null || true
            break
        fi
        sleep 2
    done
) &
WATCHER_PID=$!

# Ждём завершения основного процесса
wait "$APPLY_PID"
RC=$?

# Сводка
LOG_FILE="$LOG" RC="$RC" RUN_START="$RUN_START" python3 /app/_summary.py || true

exit $RC
