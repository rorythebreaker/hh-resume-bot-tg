#!/bin/bash
# Pre-flight compatibility check before bumping the pinned hh-applicant-tool
# version in the Dockerfile. Downloads both versions into a temp dir with
# --no-deps (nothing is installed into the system) and verifies every contract
# this project depends on: the captcha patch anchor, CLI flags used by
# run-apply.py, log lines parsed by tg_*.py/_summary.py and the auth prompts
# consumed by auth_helper.py.
#
# Usage. If the host has no pip, run it inside the project image (it already
# has Python 3.11 + pip, nothing extra to pull):
#   docker run --rm -v "$PWD:/w" -w /w hh_applicant_tool:latest \
#     bash -c 'NEW_VERSION=1.8.26 bash check_version_compat.sh'
#
# On a host that does have pip:
#   NEW_VERSION=1.8.26 bash check_version_compat.sh

set -u

OLD_VERSION="${OLD_VERSION:-1.8.12}"
NEW_VERSION="${NEW_VERSION:-1.8.26}"

if command -v pip >/dev/null 2>&1; then
    PIP="pip"
elif command -v pip3 >/dev/null 2>&1; then
    PIP="pip3"
elif command -v python3 >/dev/null 2>&1 && python3 -m pip --version >/dev/null 2>&1; then
    PIP="python3 -m pip"
else
    echo "pip not found. Run this script inside the project image instead:"
    echo "  docker run --rm -v \"\$PWD:/w\" -w /w hh_applicant_tool:latest \\"
    echo "    bash -c 'NEW_VERSION=$NEW_VERSION bash check_version_compat.sh'"
    exit 1
fi

WORK="$(mktemp -d)"
OLD="$WORK/old"
NEW="$WORK/new"
FAIL=0
WARN=0

ok()   { echo "  [OK]   $*"; }
bad()  { echo "  [FAIL] $*"; FAIL=$((FAIL + 1)); }
warn() { echo "  [WARN] $*"; WARN=$((WARN + 1)); }
hdr()  { echo; echo "=== $* ==="; }

cleanup() { rm -rf "$WORK"; }
trap cleanup EXIT

echo "Comparing hh-applicant-tool $OLD_VERSION -> $NEW_VERSION (pip: $PIP)"
echo "Temp dir: $WORK"

hdr "0. Download both versions (--no-deps)"
$PIP install --quiet --no-deps --target "$OLD" "hh-applicant-tool==$OLD_VERSION" \
    || { echo "cannot download $OLD_VERSION"; exit 1; }
$PIP install --quiet --no-deps --target "$NEW" "hh-applicant-tool==$NEW_VERSION" \
    || { echo "cannot download $NEW_VERSION"; exit 1; }
ok "downloaded"

OLD_PKG="$OLD/hh_applicant_tool"
NEW_PKG="$NEW/hh_applicant_tool"
[ -d "$NEW_PKG" ] || { echo "package dir not found in $NEW"; exit 1; }

hdr "1. File-level diff (which modules changed at all)"
diff -rq -x '__pycache__' -x '*.pyc' "$OLD_PKG" "$NEW_PKG" 2>/dev/null | sed 's|'"$WORK"'/||g' | sed 's/^/  /'

hdr "2. Captcha patch anchor (patch_captcha.py)"
AUTH="$NEW_PKG/operations/authorize.py"
if [ ! -f "$AUTH" ]; then
    bad "operations/authorize.py is gone — patch_captcha.py and auth_helper.py need rework"
else
    grep -q "img_bytes = await captcha_element.screenshot()" "$AUTH" \
        && ok "anchor line found" \
        || bad "anchor line NOT found — patch_captcha.py would silently skip, captcha PNG never reaches Telegram"
    grep -q "SEL_CAPTCHA_IMAGE" "$AUTH" \
        && ok "SEL_CAPTCHA_IMAGE present" \
        || bad "SEL_CAPTCHA_IMAGE missing — the wait_for_function insert would raise AttributeError"
    grep -q 'wait_until="load"' "$AUTH" \
        && ok "wait_until=\"load\" present (patch_goto.py has something to patch)" \
        || warn "wait_until=\"load\" not found — проверьте, нужен ли ещё patch_goto.py"
    grep -q "selector_timeout" "$AUTH" \
        && ok "selector_timeout present" \
        || bad "selector_timeout missing — the wait_for_function insert would raise AttributeError"
fi

hdr "3. Patch actually applies and the result compiles"
if [ -f "$AUTH" ] && [ -f ./patch_captcha.py ]; then
    cp -r "$NEW_PKG" "$WORK/patched_pkg"
    PYTHONPATH="$WORK" python3 - "$WORK/patched_pkg/operations/authorize.py" <<'PY'
import re, sys
path = sys.argv[1]
src = open(path, encoding="utf-8").read()
TARGET = "        img_bytes = await captcha_element.screenshot()"
if ".auth_captcha.png" in src:
    print("  [WARN] already patched?!")
elif TARGET not in src:
    print("  [FAIL] target not found")
    sys.exit(1)
else:
    src = src.replace(TARGET, "        pass\n" + TARGET, 1)
    open(path, "w", encoding="utf-8").write(src)
    print("  [OK]   patch applied to a copy")
PY
    python3 -m py_compile "$WORK/patched_pkg/operations/authorize.py" \
        && ok "patched authorize.py compiles" \
        || bad "patched authorize.py does NOT compile"
else
    warn "run this script from the project dir (patch_captcha.py not found) — step skipped"
fi

hdr "4. CLI flags used by run-apply.py (apply-vacancies)"
APPLY="$NEW_PKG/operations/apply_vacancies.py"
if [ ! -f "$APPLY" ]; then
    bad "operations/apply_vacancies.py is gone — run-apply.py needs rework"
else
    # A flag may be written with either quote style, so accept both.
    for flag in -L --force-message --search --area --resume-id --excluded-filter; do
        grep -qE -- "[\"']${flag}[\"']" "$APPLY" \
            && ok "flag $flag still declared" \
            || bad "flag $flag NOT found in apply_vacancies.py — run-apply.py will fail with 'unrecognized arguments'"
    done
fi

hdr "5. Global --profile flag (hh-run-all.sh, auth_helper.py, tg_bot.py)"
grep -rq -- '"--profile"' "$NEW_PKG"/*.py \
    && ok "--profile still declared" \
    || bad "--profile NOT found — every wrapper script breaks"

hdr "6. Log lines parsed by tg_watcher.py / tg_notifier.py / tg_bot.py / _summary.py"
grep -rq "with params" "$NEW_PKG" \
    && ok '"... POST <url> with params: {...}" debug line still emitted' \
    || bad 'debug line "with params" gone — TG notifications and the 200/day counter stop working'
grep -rq "Пробуем откликнуться" "$NEW_PKG" \
    && ok '"Пробуем откликнуться" still emitted' \
    || warn '"Пробуем откликнуться" gone — _summary.py "tried" counter breaks'
grep -rqE "Лимит откликов|Достигли лимита на отклики" "$NEW_PKG" \
    && ok "daily-limit message still emitted" \
    || warn "daily-limit message changed — limit detection in _summary.py/tg_bot.py breaks"
grep -rq "Отправлено:" "$NEW_PKG" \
    && ok '"Отправлено: N" summary line still emitted' \
    || warn '"Отправлено: N" gone — _summary.py sent counter breaks'

hdr "7. Auth prompts consumed by auth_helper.py"
grep -rq "Введите текст с картинки" "$NEW_PKG" \
    && ok "captcha prompt text unchanged" \
    || bad "captcha prompt changed — auth_helper.py PROMPT_MARK never matches, captcha block never flushed"
grep -rqE '"-k"|--use-kitty' "$NEW_PKG" \
    && ok "auth -k flag still exists" \
    || bad "auth -k flag gone — auth_helper.py command line invalid"

hdr "8. clear-negotiations (-d) and where the xsrf token comes from"
CLEAR="$(ls "$NEW_PKG"/operations/clear_negotiations.py 2>/dev/null)"
if [ -z "$CLEAR" ]; then
    bad "operations/clear_negotiations.py is gone — crontab job and tg_bot cmd_cleanup break"
else
    grep -q -- '"-d"' "$CLEAR" \
        && ok "-d flag still declared" \
        || bad "-d flag gone — 'clear-negotiations -d' becomes invalid"
fi
echo "  --- xsrf handling in $NEW_VERSION:"
grep -rnI -i "xsrf" --exclude-dir=__pycache__ "$NEW_PKG" | sed 's|'"$NEW_PKG"'|.|' | head -20 | sed 's/^/  /'
echo "  --- xsrf handling in $OLD_VERSION (what prod runs now):"
grep -rnI -i "xsrf" --exclude-dir=__pycache__ "$OLD_PKG" | sed 's|'"$OLD_PKG"'|.|' | head -20 | sed 's/^/  /'

hdr "9. New moving parts introduced since $OLD_VERSION"
for f in operations/migrate.py operations/settings.py operations/ui.py operations/clear_skipped.py; do
    if [ -f "$NEW_PKG/$f" ] && [ ! -f "$OLD_PKG/$f" ]; then
        warn "new: $f (see notes about DB migrations)"
    fi
done
if ! diff -q "$OLD_PKG/storage/queries/schema.sql" "$NEW_PKG/storage/queries/schema.sql" >/dev/null 2>&1; then
    warn "storage schema.sql changed — existing config/*/data may need 'hh-applicant-tool migrate'"
fi

hdr "RESULT"
echo "  failures: $FAIL, warnings: $WARN"
[ "$FAIL" -eq 0 ] && echo "  Safe to bump the Dockerfile." \
                  || echo "  DO NOT bump yet — fix the failures above first."
exit "$FAIL"
