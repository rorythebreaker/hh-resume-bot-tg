#!/usr/bin/env python3
"""
HH-applicant Telegram bot.

Управление полностью кнопочное (нижняя reply-клавиатура с под-меню):
  Корень:     📊 Просмотр | 🎛 Управление | 👤 Профиль | ❓ Справка
  Просмотр:   статус, лимит, статистика, последние отклики, статусы на HH, лог
  Управление: запустить, пауза, возобновить, удалить отказы
  Профиль:    письмо/запрос (показать/изменить), переименовать, регион,
              авторизовать HH, сменить/создать/удалить профиль, список

Набираемые команды: только /start и /menu (возврат к корневой клавиатуре).
"""
import os
import sys
import time
import re
import html
import json
import base64
import sqlite3
import datetime as dt
import threading
import subprocess
import urllib.request
import urllib.parse
import urllib.error
from pathlib import Path
from collections import Counter

# Добавляем /app в путь для импорта profiles_lib
sys.path.insert(0, "/app")
import profiles_lib

TG_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
# Во VK-режиме токен Telegram не нужен: адресат берётся из VK_PEER_ID.
TG_CHAT = str(os.environ.get("TG_CHAT_ID") or os.environ.get("VK_PEER_ID") or "")

CONFIG_DIR = Path(os.environ.get("CONFIG_DIR", "/app/config"))
APP_DIR = Path("/app")
LETTERS_DIR = APP_DIR / "letters"

PAUSE_FLAG = CONFIG_DIR / ".paused"
PID_FILE = CONFIG_DIR / ".apply.pid"
APPLY_SCRIPT = APP_DIR / "apply-vacancies.sh"
APPLY_WITH_NOTIFY = APP_DIR / "apply_with_notify.sh"

# Файлы для коммуникации с auth_helper в основном контейнере
AUTH_REQ = CONFIG_DIR / ".auth_request"
AUTH_OUT = CONFIG_DIR / ".auth_output"
AUTH_IN = CONFIG_DIR / ".auth_input"
AUTH_STATUS = CONFIG_DIR / ".auth_status"
AUTH_CANCEL = CONFIG_DIR / ".auth_cancel"
AUTH_CAPTCHA = CONFIG_DIR / ".auth_captcha.png"

API = f"https://api.telegram.org/bot{TG_TOKEN}"

# Контейнер запущен с TZ=Europe/Moscow (см. docker-compose.yml),
# поэтому datetime.now() уже даёт московское время.


def now_msk():
    """Текущее время в Москве (naive datetime, контейнер в TZ=Europe/Moscow)."""
    return dt.datetime.now()


def fmt_dt(d, with_msk_label=True):
    """Форматирует datetime в строку с пометкой МСК."""
    s = d.strftime("%Y-%m-%d %H:%M")
    return f"{s} МСК" if with_msk_label else s


# Состояние диалога — какой команды ожидаем ввод
# Возможные значения action:
#   "letter_set"          - заменяем письмо активного профиля
#   "search_set"          - заменяем запрос активного профиля
#   "profile_rename"      - переименовываем display_name активного профиля
#   "area_set"            - меняем регион (area) активного профиля
#   "profile_add:name"    - создаём профиль, шаг 1 (имя)
#   "profile_add:search"  - создаём профиль, шаг 2 (запрос)
#   "auth_input"          - ждём ответа в диалоге авторизации
#   "letter_new:name"     - создаём новый файл письма (имя)
#   "letter_new:text"     - создаём новый файл письма (содержимое)
PENDING = {"action": None, "data": None}

# Выбор резюме активного профиля через меню (inline). Хранит список для callback.
RESUME_PICK = {"pid": None, "resumes": None}

# Состояние диалога авторизации (в памяти, не персистится)
AUTH_DIALOG = {
    "active": False,        # идёт ли сейчас auth
    "profile_id": None,     # внутренний id профиля
    "hh_account": None,     # для какого hh_account
    "started_at": None,
    "last_prompt_msg_id": None,
}
AUTH_LOCK = threading.Lock()

CRON_FILE = APP_DIR / "crontab"

# Дневной лимит HH (отклики за сутки)
HH_DAILY_LIMIT = 200

STATE_NAMES = {
    "response": "📨 Отклик отправлен",
    "invitation": "🎯 Приглашение",
    "discard": "❌ Отказ",
    "discard_no_appropriate": "❌ Отказ (не подходит)",
    "discard_by_employer": "❌ Отказ от работодателя",
    "discard_by_applicant": "↩️ Отозван вами",
    "discard_to_other_vacancy": "↪️ Переведён на другую вакансию",
    "discard_after_interview": "❌ Отказ после собеседования",
    "hidden": "🙈 Скрыт",
    "archived": "📦 Архив",
    "applicant_not_relevant": "❌ Не релевантен",
    "phone_interview": "📞 Телефонное интервью",
    "assessment": "📝 Тестовое задание",
    "offer": "🎉 Оффер",
}


# =================== Транспорт (Telegram / VK) ===================
# BOT_TRANSPORT=vk переводит бота во ВКонтакте: вся логика меню и команд
# остаётся общей, меняются только отправка, приём и клавиатуры.
TRANSPORT = os.environ.get("BOT_TRANSPORT", "telegram").strip().lower()
VK = None
if TRANSPORT == "vk":
    import vk_transport
    VK = vk_transport.VKTransport()
    print("Transport: VK", flush=True)


# =================== Telegram API ===================

def api_call(method, **params):
    url = f"{API}/{method}"
    data = urllib.parse.urlencode(params).encode() if params else None
    req = urllib.request.Request(url, data=data)
    with urllib.request.urlopen(req, timeout=70) as r:
        return json.loads(r.read())


def send(chat_id, text, parse_mode="HTML"):
    if VK:
        return VK.send_text(chat_id, text)
    MAX = 3900
    while text:
        chunk, text = text[:MAX], text[MAX:]
        try:
            api_call("sendMessage", chat_id=chat_id, text=chunk,
                     parse_mode=parse_mode, disable_web_page_preview="true")
        except Exception as e:
            print(f"send failed: {e}", file=sys.stderr)


def send_plain(chat_id, text):
    """Без HTML/Markdown — для отображения файлов с спецсимволами."""
    if VK:
        return VK.send_text(chat_id, text)
    MAX = 3900
    while text:
        chunk, text = text[:MAX], text[MAX:]
        try:
            api_call("sendMessage", chat_id=chat_id, text=chunk,
                     disable_web_page_preview="true")
        except Exception as e:
            print(f"send failed: {e}", file=sys.stderr)


def _tg_upload(method, field, data_bytes, chat_id, caption, filename, ctype):
    """Загрузка файла из памяти в Telegram (multipart/form-data)."""
    boundary = "----hhbot" + os.urandom(8).hex()
    b = boundary.encode()
    parts = [
        b"--" + b + b"\r\n",
        b'Content-Disposition: form-data; name="chat_id"\r\n\r\n',
        str(chat_id).encode() + b"\r\n",
    ]
    if caption:
        parts += [
            b"--" + b + b"\r\n",
            b'Content-Disposition: form-data; name="caption"\r\n\r\n',
            caption.encode("utf-8") + b"\r\n",
        ]
    parts += [
        b"--" + b + b"\r\n",
        f'Content-Disposition: form-data; name="{field}"; filename="{filename}"\r\n'.encode(),
        f"Content-Type: {ctype}\r\n\r\n".encode(),
        data_bytes + b"\r\n",
        b"--" + b + b"--\r\n",
    ]
    body = b"".join(parts)
    req = urllib.request.Request(f"{API}/{method}", data=body)
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read())
    except Exception as e:
        print(f"{method} failed: {e}", file=sys.stderr)
        return None


def send_captcha_image(chat_id, png_bytes, caption=""):
    if VK:
        # Картинкой, а не документом: VK показывает фото сразу в ленте чата.
        return VK.send_file(chat_id, png_bytes, "captcha.png", caption, as_photo=True)
    """Шлёт PNG капчи файлом (документом): Telegram не сжимает документы,
    мелкий текст капчи остаётся чётким. Если sendDocument не прошёл —
    пробуем как фото (на крайний случай)."""
    resp = _tg_upload("sendDocument", "document", png_bytes, chat_id, caption,
                      "captcha.png", "image/png")
    if resp and resp.get("ok"):
        return resp
    return _tg_upload("sendPhoto", "photo", png_bytes, chat_id, caption,
                      "captcha.png", "image/png")


# =================== Нижние reply-клавиатуры ===================

# Нижняя постоянная reply-панель: 5 главных кнопок в один ряд.
QUICK_KB = {
    "keyboard": [[
        {"text": "🎛 Меню"},
        {"text": "▶️ Старт"},
        {"text": "⏸ Пауза"},
        {"text": "▶️ Возобновить"},
        {"text": "⏰ Лимит"},
    ]],
    "resize_keyboard": True,
    "is_persistent": True,
}
QUICK_PANEL = ["🎛 Меню", "▶️ Старт", "⏸ Пауза", "▶️ Возобновить", "⏰ Лимит"]
QUICK_LABELS = set(QUICK_PANEL)


def set_panel(chat_id, text):
    """Ставит/обновляет нижнюю reply-панель."""
    if VK:
        return VK.set_panel(chat_id, text, QUICK_PANEL)
    try:
        api_call(
            "sendMessage", chat_id=chat_id, text=text,
            parse_mode="HTML", disable_web_page_preview="true",
            reply_markup=json.dumps(QUICK_KB),
        )
    except Exception as e:
        print(f"set_panel failed: {e}", file=sys.stderr)


def tg_delete(chat_id, msg_id):
    """Удаляет сообщение (нажатие нижней кнопки). Ошибки игнорируем."""
    if not msg_id:
        return
    if VK:
        return VK.delete_message(chat_id, msg_id)
    try:
        api_call("deleteMessage", chat_id=chat_id, message_id=msg_id)
    except Exception:
        pass


# =================== Утилиты ===================

def active_hh_account():
    """Возвращает hh_account активного профиля (или 'main' по умолчанию)."""
    pid, profile = profiles_lib.get_active_profile()
    if profile:
        return profile.get("hh_account", "main")
    return "main"


def active_config_dir():
    """Каталог конфига активного HH-аккаунта. Fallback на старый CONFIG_DIR."""
    acc = active_hh_account()
    candidate = CONFIG_DIR / acc
    if (candidate / "config.json").is_file() or candidate.is_dir():
        return candidate
    return CONFIG_DIR


def find_db():
    acc_dir = active_config_dir()
    for c in [acc_dir / "data", CONFIG_DIR / "data", CONFIG_DIR / "data.db"]:
        if c.is_file():
            return c
    for p in CONFIG_DIR.rglob("data*"):
        if p.is_file() and p.stat().st_size > 0:
            return p
    return None


def db():
    db_path = find_db()
    if db_path is None:
        raise FileNotFoundError("Database not found")
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def state_label(s):
    return STATE_NAMES.get(s, f"❓ {s}" if s else "—")


def is_paused():
    return PAUSE_FLAG.exists()


def _read_token_for_account():
    """Читает access_token из config.json активного HH-аккаунта."""
    acc_dir = active_config_dir()
    cfg_path = acc_dir / "config.json"
    if not cfg_path.is_file():
        cfg_path = CONFIG_DIR / "config.json"
    if not cfg_path.is_file():
        return None
    try:
        cfg = json.loads(cfg_path.read_text())
        return (cfg.get("token") or {}).get("access_token") or cfg.get("access_token")
    except Exception as e:
        print(f"token read failed: {e}", file=sys.stderr)
        return None


def hh_get(path):
    """GET к HH API напрямую с токеном активного аккаунта."""
    token = _read_token_for_account()
    if not token:
        print("config.json / token not found", file=sys.stderr)
        return {}

    url = f"https://api.hh.ru{path}" if path.startswith("/") else f"https://api.hh.ru/{path}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "hh-applicant-tool/bot",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read()) or {}
    except Exception as e:
        print(f"HH API failed ({path}): {e}", file=sys.stderr)
        return {}


def fetch_resumes_for_account(hh_account):
    """[(id, title), ...] резюме аккаунта. [] если нет токена/резюме/ошибка."""
    cfg_path = CONFIG_DIR / hh_account / "config.json"
    if not cfg_path.is_file():
        return []
    try:
        cfg = json.loads(cfg_path.read_text())
        token = (cfg.get("token") or {}).get("access_token") or cfg.get("access_token")
    except Exception as e:
        print(f"resume token read failed: {e}", file=sys.stderr)
        return []
    if not token:
        return []
    req = urllib.request.Request(
        "https://api.hh.ru/resumes/mine",
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "hh-applicant-tool/bot",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read()) or {}
    except Exception as e:
        print(f"resumes fetch failed: {e}", file=sys.stderr)
        return []
    out = []
    for it in data.get("items", []):
        rid = it.get("id")
        if rid:
            out.append((rid, it.get("title") or "(без названия)"))
    return out


def read_search_for_active():
    """Возвращает поисковый запрос активного профиля."""
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return ""
    return profile.get("search", "")


def write_search_for_active(new_search):
    """Сохраняет новый поисковый запрос для активного профиля."""
    if "'" in new_search:
        raise ValueError("Поисковый запрос не должен содержать одиночные кавычки (')")

    pid, profile = profiles_lib.get_active_profile()
    if not pid:
        raise RuntimeError("Нет активного профиля")
    profiles_lib.update_profile(pid, search=new_search)


def get_active_letter_path():
    """Возвращает путь к файлу письма активного профиля."""
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return None
    return profiles_lib.get_letter_path(profile)


def get_active_tool_log():
    """Путь к log.txt активного hh_account. Fallback на старый путь."""
    pid, profile = profiles_lib.get_active_profile()
    if profile:
        hh_account = profile.get("hh_account", "main")
        candidate = CONFIG_DIR / hh_account / "log.txt"
        if candidate.exists():
            return candidate
    # Fallback: старый путь (для совместимости при миграции)
    return CONFIG_DIR / "log.txt"


# =================== Команды ===================

def cmd_help():
    return (
        "🎛 <b>Управление ботом</b>\n\n"
        "<b>Нижняя панель (всегда внизу):</b>\n"
        "• 🎛 Меню — открыть полное меню\n"
        "• ▶️ Старт — запустить рассылку сейчас\n"
        "• ⏸ Пауза / ▶️ Возобновить — пауза рассылки\n"
        "• ⏰ Лимит — следующий прогон и остаток лимита\n\n"
        "<b>В «🎛 Меню»:</b>\n"
        "• 📊 Просмотр — статус, лимит, статистика, последние 10, статусы на HH, лог\n"
        "• 🎛 Управление — запустить, пауза, возобновить, удалить отказы\n"
        "• 👤 Профиль — письмо и запрос, переименовать, регион, авторизовать HH, "
        "сменить/создать/удалить профиль, список\n\n"
        "Ввод текста (письмо/запрос/имя/регион) отменяется командой /cancel."
    )


def cmd_status():
    """Статус системы. Новый порядок:
    - Заголовок
    - Свободно сейчас
    - Сегодняшний день
    - Текущее время
    - Активность/пауза
    - Сводка за 24ч одной фразой
    - Лимит-блок (если близко к лимиту)
    - Размер лога
    """
    try:
        items = parse_log_applies()
    except Exception as e:
        return f"⚠️ Ошибка чтения лога: {html.escape(str(e))}"

    now = now_msk()
    st = compute_limits_state(items, now)

    lines = ["<b>⚙️ Статус системы</b>"]
    lines.append("")
    lines.append(f"Свободно сейчас: <b>{st['free_now']}</b>")
    lines.append("")
    today_str = now.strftime("%d.%m")
    today_word = plural_ru(st["calendar_today"], ("отклик", "отклика", "откликов"))
    lines.append(f"За сегодняшний день ({today_str}): <b>{st['calendar_today']}</b> {today_word}")
    lines.append("")
    lines.append(f"🕒 Сейчас: <b>{fmt_dt(now)}</b>")
    lines.append(f"Отклики: {'⏸ ПАУЗА' if is_paused() else '▶️ АКТИВНЫ'}")

    if PENDING["action"]:
        lines.append(f"Ожидание ввода: <code>{PENDING['action']}</code> (/cancel — отменить)")

    lines.append(f"За последние 24ч было сделано <b>{st['in_window']}</b> из {HH_DAILY_LIMIT} откликов.")

    return "\n".join(lines)


def cmd_pause():
    try:
        PAUSE_FLAG.parent.mkdir(parents=True, exist_ok=True)
        PAUSE_FLAG.touch()
        was_running = PID_FILE.exists()
        msg = "⏸ <b>Отклики приостановлены.</b>\nЗапланированные задачи будут пропускаться."
        if was_running:
            msg += "\n💥 Активный прогон будет прерван в течение ~5 секунд."
        msg += "\nВозобновить — кнопка «▶️ Возобновить»"
        return msg
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"


def cmd_resume():
    try:
        if PAUSE_FLAG.exists():
            PAUSE_FLAG.unlink()
        return "▶️ <b>Отклики возобновлены.</b>"
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"


def cmd_run(chat_id):
    """Запускает apply_with_notify.sh в фоне, ничего не блокируя."""
    if is_paused():
        return "⏸ Сейчас стоит пауза. Жми «▶️ Возобновить»."

    def runner():
        try:
            send(chat_id, "🚀 Запускаю рассылку...")
            res = subprocess.run(
                ["/bin/bash", str(APPLY_WITH_NOTIFY)],
                capture_output=True, text=True, timeout=900,
            )
            print(f"manual run finished, rc={res.returncode}")
            # Сводка будет отправлена самим apply_with_notify.sh
        except subprocess.TimeoutExpired:
            send(chat_id, "⚠️ Прогон не завершился за 15 минут.")
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка запуска: {html.escape(str(e))}")

    threading.Thread(target=runner, daemon=True).start()
    return "✅ Запущено в фоне. Сводка придёт по завершении."


def cmd_letter_show():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля. Создай профиль кнопкой «➕ Создать профиль»."
    letter_path = profiles_lib.get_letter_path(profile)
    if not letter_path.exists():
        return f"❌ Файл письма не найден: {letter_path.name}"
    text = letter_path.read_text()
    display = profile.get("display_name") or pid
    return (
        f"📝 <b>Письмо профиля «{html.escape(display)}»</b>\n"
        f"Файл: <code>{html.escape(letter_path.name)}</code> ({len(text)} симв.)\n\n"
        f"<pre>{html.escape(text)}</pre>"
    )


def cmd_letter_set_prompt():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    letter_path = profiles_lib.get_letter_path(profile)
    PENDING["action"] = "letter_set"
    PENDING["data"] = str(letter_path)
    return (
        f"✏️ Замена письма <code>{html.escape(letter_path.name)}</code>\n"
        "Пришли новый текст письма <b>одним сообщением</b>.\n\n"
        "Доступные плейсхолдеры:\n"
        "• <code>%(vacancy_name)s</code> — название вакансии\n"
        "• <code>%(employer_name)s</code> — компания\n"
        "• <code>%(first_name)s</code>, <code>%(last_name)s</code>\n"
        "• <code>%(email)s</code>, <code>%(phone)s</code>\n"
        "\nСинтаксис рандомизации: <code>{вариант1|вариант2|вариант3}</code>\n"
        "\nОтменить — командой /cancel"
    )


def cmd_letter_save(text):
    try:
        if len(text) < 50:
            return "⚠️ Текст слишком короткий (минимум 50 символов). /cancel — отменить, или пришли заново."
        if len(text) > 5000:
            return "⚠️ Текст слишком длинный (максимум 5000 символов)."

        target_path = Path(PENDING["data"]) if PENDING["data"] else None
        if not target_path:
            return "⚠️ Ошибка: не задан путь файла."

        # letter_default.txt — общий шаблон: правка в нём затронула бы все
        # профили, которые на него ещё смотрят. Отводим профилю свой файл.
        pid, profile = profiles_lib.get_active_profile()
        moved_to = None
        if pid and target_path.name == profiles_lib.DEFAULT_LETTER:
            target_path = target_path.with_name(f"letter_{pid}.txt")
            moved_to = target_path.name

        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(text)
        if moved_to:
            profiles_lib.update_profile(pid, letter=moved_to)
        PENDING["action"] = None
        PENDING["data"] = None
        note = f"\nПрофиль переведён на свой файл: <code>{html.escape(moved_to)}</code>" if moved_to else ""
        return (f"✅ Письмо обновлено ({len(text)} симв.): "
                f"<code>{html.escape(target_path.name)}</code>{note}")
    except PermissionError as e:
        return ("⚠️ Нет прав на запись в каталог писем.\n"
                "Бот работает под UID 1000, а каталог принадлежит другому пользователю.\n\n"
                "На сервере:\n<pre>chown -R 1000:1000 letters profiles.json</pre>\n"
                f"<i>{html.escape(str(e))}</i>")
    except Exception as e:
        return f"⚠️ Ошибка сохранения: {html.escape(str(e))}"


def cmd_search_show():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    search = profile.get("search", "")
    if not search:
        return "❌ Поисковый запрос пуст. Задай кнопкой «✏️ Изменить запрос»."
    display = profile.get("display_name") or pid
    return (
        f"🔍 <b>Запрос профиля «{html.escape(display)}»</b> ({len(search)} симв.):\n\n"
        f"<pre>{html.escape(search)}</pre>\n\n"
        f"Документация по языку запросов HH: hh.ru/article/1175"
    )


def cmd_search_set_prompt():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    display = profile.get("display_name") or pid
    PENDING["action"] = "search_set"
    return (
        f"✏️ Замена запроса профиля «{html.escape(display)}»\n"
        "Пришли новый поисковый запрос <b>одним сообщением</b>.\n\n"
        "Поддерживается язык запросов HH:\n"
        "• <code>AND</code>, <code>OR</code>, <code>NOT</code>\n"
        "• Скобки <code>( )</code>\n"
        "• Кавычки <code>\" \"</code> для фраз\n"
        "\n⚠️ <b>Не используй одиночные кавычки</b> <code>'</code> — только двойные.\n"
        "\nПример: <code>(devops OR sre) AND linux NOT helpdesk</code>\n"
        "\nОтменить — командой /cancel"
    )


def cmd_search_save(text):
    try:
        text = text.strip()
        if len(text) < 5:
            return "⚠️ Запрос слишком короткий."
        if len(text) > 3000:
            return "⚠️ Запрос слишком длинный (максимум 3000)."

        write_search_for_active(text)
        PENDING["action"] = None
        return f"✅ Поисковый запрос обновлён ({len(text)} симв.)"
    except ValueError as e:
        return f"⚠️ {html.escape(str(e))}"
    except Exception as e:
        return f"⚠️ Ошибка сохранения: {html.escape(str(e))}"


def cmd_cancel():
    # Если идёт auth-диалог — отменяем его
    with AUTH_LOCK:
        if AUTH_DIALOG["active"]:
            AUTH_DIALOG["active"] = False
            AUTH_DIALOG["profile_id"] = None
            AUTH_DIALOG["hh_account"] = None
            try:
                AUTH_CANCEL.touch()
            except Exception as e:
                print(f"cancel auth failed: {e}", file=sys.stderr)
            return "❎ Авторизация отменена."

    was = PENDING["action"]
    PENDING["action"] = None
    PENDING["data"] = None
    if was:
        return f"❎ Отменено ожидание: <code>{was}</code>"
    return "Нет активного ожидания ввода."


# =================== Профили ===================

def cmd_profiles():
    """Список всех профилей."""
    items = profiles_lib.list_profiles()
    if not items:
        return "Профилей пока нет. Создай кнопкой «➕ Создать профиль»."
    active_pid, _ = profiles_lib.get_active_profile()
    lines = ["<b>👥 Профили:</b>\n"]
    for pid, p in items:
        marker = "▶️" if pid == active_pid else "  "
        display = p.get("display_name") or pid
        hh_acc = p.get("hh_account", "main")
        search_short = (p.get("search") or "")[:40]
        if len(p.get("search") or "") > 40:
            search_short += "…"
        lines.append(
            f"{marker} <b>{html.escape(display)}</b>\n"
            f"   HH-аккаунт: <code>{html.escape(hh_acc)}</code>\n"
            f"   Запрос: <code>{html.escape(search_short)}</code>"
        )
    return "\n".join(lines)


def cmd_profile_rename_prompt():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    display = profile.get("display_name") or pid
    PENDING["action"] = "profile_rename"
    return (
        f"🏷 Переименование профиля «{html.escape(display)}»\n"
        "Пришли новое имя одним сообщением (1-50 символов).\n\n"
        "Отменить — командой /cancel"
    )


def cmd_profile_rename_save(text):
    text = text.strip()
    if len(text) < 1 or len(text) > 50:
        return "⚠️ Имя должно быть 1-50 символов."
    pid, _ = profiles_lib.get_active_profile()
    if not pid:
        return "❌ Нет активного профиля."
    try:
        profiles_lib.update_profile(pid, display_name=text)
        PENDING["action"] = None
        return f"✅ Профиль переименован: «{html.escape(text)}»"
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"


def fetch_area_name(area_id):
    """Запрашивает название региона у api.hh.ru/areas/{id}.
    Возвращает кортеж (status, name):
      status="valid"       — код существует, name = название
      status="invalid"     — код не существует (404)
      status="unreachable" — api.hh.ru недоступен/таймаут, name = None
    """
    url = f"https://api.hh.ru/areas/{area_id}"
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "hh-applicant-tool/bot",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read()) or {}
        return ("valid", data.get("name") or str(area_id))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return ("invalid", None)
        return ("unreachable", None)
    except Exception:
        return ("unreachable", None)


def cmd_area_prompt():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    current = profile.get("area", 113)
    status, name = fetch_area_name(current)
    if status == "valid":
        current_line = f"Текущий регион: <b>{current}</b> — {html.escape(name)}"
    else:
        current_line = f"Текущий регион: <b>{current}</b>"
    PENDING["action"] = "area_set"
    return (
        f"🌍 Смена региона активного профиля.\n"
        f"{current_line}\n\n"
        "Пришли <b>числовой код</b> региона одним сообщением.\n"
        "Примеры: 113 — Россия, 1 — Москва, 2 — СПб.\n"
        "Справочник: https://api.hh.ru/areas\n\n"
        "Отменить — командой /cancel"
    )


def cmd_area_save(text):
    text = text.strip()
    if not text.isdigit():
        return "⚠️ Нужен числовой код региона. Попробуй ещё раз или /cancel."
    area_id = int(text)
    pid, _ = profiles_lib.get_active_profile()
    if not pid:
        return "❌ Нет активного профиля."

    status, name = fetch_area_name(area_id)
    if status == "invalid":
        return f"⚠️ Региона с кодом {area_id} не существует. Попробуй ещё раз или /cancel."

    try:
        profiles_lib.update_profile(pid, area=area_id)
        PENDING["action"] = None
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"

    if status == "valid":
        return f"✅ Регион изменён: <b>{area_id}</b> — {html.escape(name)}"
    return (
        f"✅ Регион изменён: <b>{area_id}</b>\n"
        "(api.hh.ru недоступен — сохранено без проверки названия)"
    )


def cmd_profile_add_start():
    """Запускает диалог создания профиля."""
    PENDING["action"] = "profile_add:name"
    PENDING["data"] = {}
    return (
        "➕ <b>Создание нового профиля</b>\n\n"
        "Шаг 1/3: Пришли <b>название профиля</b> (как ты его будешь видеть в боте).\n"
        "Например: «DevOps», «Сисадмин Москва», «Второй аккаунт»\n\n"
        "Отменить — командой /cancel"
    )


def cmd_profile_add_step(text):
    """Обработка шагов создания профиля."""
    text = text.strip()
    step = PENDING["action"].split(":", 1)[1]
    data = PENDING.get("data") or {}

    if step == "name":
        if len(text) < 1 or len(text) > 50:
            return "⚠️ Название должно быть 1-50 символов."
        data["display_name"] = text
        PENDING["action"] = "profile_add:search"
        PENDING["data"] = data
        return (
            f"✅ Название: <b>{html.escape(text)}</b>\n\n"
            "Шаг 2/3: Пришли <b>поисковый запрос</b> для HH.\n\n"
            "Поддерживается язык запросов HH:\n"
            "• <code>AND</code>, <code>OR</code>, <code>NOT</code>\n"
            "• Скобки <code>( )</code>\n"
            "• Кавычки <code>\" \"</code> для фраз\n\n"
            "⚠️ Не используй одиночные кавычки <code>'</code>.\n\n"
            "Пример: <code>(devops OR sre) AND linux</code>\n\n"
            "Отменить — командой /cancel"
        )

    if step == "search":
        if "'" in text:
            return "⚠️ Запрос не должен содержать одиночные кавычки <code>'</code>. Пришли заново."
        if len(text) < 5 or len(text) > 3000:
            return "⚠️ Запрос должен быть 5-3000 символов."
        data["search"] = text
        PENDING["action"] = "profile_add:account"
        PENDING["data"] = data

        # Предложим существующие HH-аккаунты
        existing = profiles_lib.get_hh_accounts()
        accounts_hint = ""
        if existing:
            accounts_hint = (
                "\nСуществующие HH-аккаунты в системе: "
                + ", ".join(f"<code>{html.escape(a)}</code>" for a in existing)
            )
        return (
            f"✅ Запрос сохранён ({len(text)} симв.)\n\n"
            "Шаг 3/3: Пришли <b>идентификатор HH-аккаунта</b>.\n\n"
            "Это короткое имя без пробелов, например <code>main</code>, <code>second</code>, <code>backup</code>.\n"
            "Профили с одинаковым идентификатором используют один HH-аккаунт."
            f"{accounts_hint}\n\n"
            "Отменить — командой /cancel"
        )

    if step == "account":
        if not re.match(r"^[a-z0-9_-]{1,30}$", text):
            return "⚠️ Идентификатор: маленькие буквы, цифры, <code>_</code> или <code>-</code>, 1-30 символов."
        data["hh_account"] = text
        PENDING["action"] = None
        PENDING["data"] = None
        return _finalize_profile_creation(data, "")

    return f"⚠️ Неизвестный шаг: {step}"


def _finalize_profile_creation(data, resume_id=""):
    """Создаёт профиль (с пустым письмом и resume_id) и возвращает текст-итог."""
    try:
        new_pid = profiles_lib.next_profile_id()
        letter_name = f"letter_{new_pid}.txt"
        (profiles_lib.LETTERS_DIR / letter_name).write_text("")
        profiles_lib.add_profile(
            display_name=data["display_name"],
            hh_account=data["hh_account"],
            search=data["search"],
            letter=letter_name,
            area=113,
            excluded_filter="",
            resume_id=resume_id,
        )
    except Exception as e:
        return f"⚠️ Ошибка создания: {html.escape(str(e))}"

    account_config = CONFIG_DIR / data["hh_account"] / "config.json"
    auth_hint = ""
    if not account_config.exists():
        auth_hint = (
            f"\n\n⚠️ HH-аккаунт <code>{html.escape(data['hh_account'])}</code> "
            "ещё не авторизован. Авторизуй кнопкой «🔑 Авторизовать HH»."
        )
    if resume_id:
        resume_line = f"\nРезюме: <code>{html.escape(resume_id)}</code>"
    else:
        resume_line = "\nРезюме: по умолчанию (как выберет утилита)"
    return (
        f"✅ Профиль <b>«{html.escape(data['display_name'])}»</b> создан.\n"
        f"HH-аккаунт: <code>{html.escape(data['hh_account'])}</code>"
        f"{resume_line}\n"
        f"Письмо: <code>{letter_name}</code> (пустое — задай кнопкой «✏️ Изменить письмо»)"
        f"{auth_hint}\n\n"
        "Переключиться: «👤 Профиль» → «⟳ Сменить профиль»."
    )


def cmd_profile_switch(profile_id):
    """Переключает активный профиль."""
    try:
        profiles_lib.set_active_profile(profile_id)
        _, p = profiles_lib.get_active_profile()
        display = p.get("display_name") or profile_id
        return f"✅ Активный профиль: <b>{html.escape(display)}</b>"
    except ValueError:
        return "⚠️ Профиль не найден."
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"


def cmd_profile_remove(profile_id):
    """Удаляет профиль."""
    items_before = profiles_lib.list_profiles()
    if len(items_before) <= 1:
        return "⚠️ Нельзя удалить последний профиль."
    try:
        # Найдём display_name до удаления
        data = profiles_lib.load_profiles()
        if profile_id not in data["profiles"]:
            return "⚠️ Профиль не найден."
        display = data["profiles"][profile_id].get("display_name") or profile_id
        profiles_lib.remove_profile(profile_id)
        return f"✅ Профиль «{html.escape(display)}» удалён."
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"


# =================== Авторизация HH через бота ===================

def cmd_auth_start():
    """Запускает диалог авторизации для активного профиля."""
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."

    hh_account = profile.get("hh_account", "main")

    with AUTH_LOCK:
        if AUTH_DIALOG["active"]:
            return (
                f"⚠️ Авторизация уже идёт для аккаунта <code>{html.escape(AUTH_DIALOG['hh_account'])}</code>.\n"
                "Отменить — командой /cancel"
            )
        AUTH_DIALOG["active"] = True
        AUTH_DIALOG["profile_id"] = pid
        AUTH_DIALOG["hh_account"] = hh_account
        AUTH_DIALOG["started_at"] = now_msk()

    # Очищаем старые комм-файлы (включая статус — иначе наблюдатель
    # прочитает прошлую ошибку и сразу завершится).
    for f in (AUTH_OUT, AUTH_IN, AUTH_CANCEL, AUTH_STATUS, AUTH_CAPTCHA):
        try:
            if f.exists():
                f.unlink()
        except Exception:
            pass

    auth_started_ts = time.time()

    # Пишем запрос в auth_helper
    try:
        AUTH_REQ.write_text(json.dumps({
            "profile": hh_account,
            "ts": time.time(),
        }))
    except Exception as e:
        with AUTH_LOCK:
            AUTH_DIALOG["active"] = False
        return f"⚠️ Не удалось запустить: {html.escape(str(e))}"

    # Запускаем поток-наблюдатель за выводом утилиты
    threading.Thread(target=_auth_watcher, args=(TG_CHAT, auth_started_ts), daemon=True).start()

    return (
        f"🔄 Запускаю авторизацию для аккаунта <code>{html.escape(hh_account)}</code>...\n\n"
        "⚠️ Будь готов получить SMS-код.\n"
        "Когда утилита спросит — отвечай сообщением в этот чат.\n\n"
        "Отменить — командой /cancel"
    )


def _auth_watcher(chat_id, started_ts=0):
    """Фоновый поток: смотрит за .auth_output и .auth_status,
    пересылает прогресс в TG. Игнорирует статус старше started_ts."""
    start_time = time.time()
    last_msg = ""

    while True:
        with AUTH_LOCK:
            if not AUTH_DIALOG["active"]:
                return

        # Хард-таймаут 10 минут
        if time.time() - start_time > 600:
            with AUTH_LOCK:
                AUTH_DIALOG["active"] = False
            try:
                send(chat_id, "⏱ Авторизация прервана (таймаут 10 минут).")
            except Exception:
                pass
            return

        # Капча: helper кладёт готовый PNG в файл — шлём его картинкой
        if AUTH_CAPTCHA.exists():
            try:
                png = AUTH_CAPTCHA.read_bytes()
                AUTH_CAPTCHA.unlink()
                if png:
                    send_captcha_image(
                        chat_id, png,
                        "🔐 Капча. Введите текст с картинки одним сообщением.")
            except Exception as e:
                print(f"captcha send error: {e}", file=sys.stderr)

        # Читаем текстовый вывод утилиты (base64 капчи сюда уже не попадает)
        if AUTH_OUT.exists():
            try:
                content = AUTH_OUT.read_text()
                AUTH_OUT.unlink()
                content = content.strip()
                if content and content != last_msg:
                    last_msg = content
                    if len(content) > 3500:
                        content = content[:3500] + "…"
                    send(chat_id, f"🤖 <pre>{html.escape(content)}</pre>")
            except Exception as e:
                print(f"_auth_watcher read error: {e}", file=sys.stderr)

        # Проверяем статус
        if AUTH_STATUS.exists():
            try:
                status = json.loads(AUTH_STATUS.read_text())
                # Игнорируем статус, записанный до старта этой авторизации
                if status.get("ts", 0) < started_ts:
                    time.sleep(1)
                    continue
                state = status.get("state")
                msg = status.get("msg", "")
                if state == "done":
                    with AUTH_LOCK:
                        AUTH_DIALOG["active"] = False
                    send(chat_id, f"✅ <b>Авторизация успешна</b>\n{html.escape(msg)}\n\nМожно «▶️ Старт» или подождать cron.")
                    return
                if state == "error":
                    with AUTH_LOCK:
                        AUTH_DIALOG["active"] = False
                    send(chat_id, f"❌ <b>Ошибка авторизации</b>\n<pre>{html.escape(msg)}</pre>")
                    return
            except Exception:
                pass

        time.sleep(1)


def handle_auth_input(text):
    """Когда мы в auth-режиме, любой текст идёт в stdin утилиты."""
    try:
        AUTH_IN.write_text(text)
        return None  # ответ придёт через _auth_watcher
    except Exception as e:
        return f"⚠️ Не удалось передать ввод: {html.escape(str(e))}"


def parse_apply_cron_hours():
    """Читает crontab, находит строку с apply_with_notify.sh, извлекает
    список часов запуска. Возвращает (hours_list, source_str).
    На случай разбора неудачи — fallback на 8-21."""
    fallback = (list(range(8, 22)), "8-21 (по умолчанию)")
    if not CRON_FILE.exists():
        return fallback

    try:
        text = CRON_FILE.read_text()
    except Exception:
        return fallback

    # Ищем строку с apply_with_notify
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#") or not line:
            continue
        if "apply_with_notify" not in line:
            continue
        # Формат: M H DOM MON DOW <command>
        parts = line.split(None, 5)
        if len(parts) < 6:
            continue
        hour_field = parts[1]
        try:
            hours = expand_cron_hours(hour_field)
            return (hours, hour_field)
        except Exception:
            continue
    return fallback


def expand_cron_hours(field):
    """Раскрывает hour-поле cron в список часов 0-23.
    Поддерживает: '*', '8-21', '8,12,18', '*/4', '8-21/2'."""
    result = set()
    for part in field.split(","):
        step = 1
        if "/" in part:
            base, step_s = part.split("/", 1)
            step = int(step_s)
        else:
            base = part
        if base == "*":
            start, end = 0, 23
        elif "-" in base:
            a, b = base.split("-", 1)
            start, end = int(a), int(b)
        else:
            start = end = int(base)
        for h in range(start, end + 1, step):
            if 0 <= h <= 23:
                result.add(h)
    return sorted(result)


def next_cron_run(hours):
    """Возвращает следующий запуск cron как naive datetime (в МСК, т.к.
    контейнер с TZ=Europe/Moscow). Cron запускается в :00 указанных часов."""
    now = now_msk()
    for day_offset in (0, 1):
        day = now.date() + dt.timedelta(days=day_offset)
        for h in hours:
            candidate = dt.datetime.combine(day, dt.time(hour=h, minute=0))
            if candidate > now:
                return candidate
    return None


def plural_ru(n, forms):
    """Выбирает правильную форму существительного для числа n.
    forms = (форма_для_1, форма_для_2_4, форма_для_остальных)
    Пример: plural_ru(5, ('отклик', 'отклика', 'откликов')) → 'откликов'."""
    n = abs(n) % 100
    if 11 <= n <= 14:
        return forms[2]
    n %= 10
    if n == 1:
        return forms[0]
    if 2 <= n <= 4:
        return forms[1]
    return forms[2]


def fmt_timedelta(td):
    """Преобразует timedelta в строку '2ч 15м'."""
    total_sec = int(td.total_seconds())
    if total_sec < 0:
        total_sec = 0
    hours = total_sec // 3600
    minutes = (total_sec % 3600) // 60
    if hours > 0:
        return f"{hours}ч {minutes:02d}м"
    return f"{minutes}м"


def fmt_dt_short(d):
    """Короткий формат — только время или 'завтра HH:MM' если завтра."""
    now = now_msk()
    if d.date() == now.date():
        return d.strftime("%H:%M МСК")
    if d.date() == now.date() + dt.timedelta(days=1):
        return d.strftime("завтра %H:%M МСК")
    return d.strftime("%d.%m %H:%M МСК")


def compute_limits_state(items, now):
    """Возвращает структуру с полной информацией о лимитах HH.

    items: список dict(ts, vid) — все отклики из лога
    now: текущее время (naive datetime в МСК)

    Returns:
        dict с полями:
          - in_window: int — отправлено за последние 24 часа
          - free_now: int — свободно слотов сейчас
          - calendar_today: int — отправлено по календарной дате
          - window_start: datetime — начало текущего окна (now - 24ч)
          - oldest_in_window: datetime|None — время самого старого отклика в окне
          - sorted_ts_in_window: list[datetime] — все timestamps в окне (отсортированы)
          - full_reset_at: datetime|None — когда последний отклик «выпадет» из окна
          - free_slot_times: list[(int, datetime)] — пары (через сколько отрисуется N слотов, время)
    """
    window_start = now - dt.timedelta(hours=24)
    in_window_items = [x for x in items if x["ts"] >= window_start]
    sorted_ts = sorted(x["ts"] for x in in_window_items)
    in_window = len(sorted_ts)
    free_now = max(0, HH_DAILY_LIMIT - in_window)
    today = now.date()
    calendar_today = sum(1 for x in items if x["ts"].date() == today)

    oldest_in_window = sorted_ts[0] if sorted_ts else None
    # Полный сброс — когда самый свежий отклик станет старше 24ч
    full_reset_at = (sorted_ts[-1] + dt.timedelta(hours=24)) if sorted_ts else None

    # Когда освободятся первые N слотов: каждый отклик «выпадает» из окна
    # через 24ч после отправки. То есть слот #k освобождается в момент
    # sorted_ts[k-1] + 24h.
    # Если в окне 200, то первый слот откроется в sorted_ts[0]+24h.
    # 10-й слот — в sorted_ts[9]+24h. И так далее.
    free_slot_times = []
    if in_window >= HH_DAILY_LIMIT:
        # Лимит полный — показываем когда откроются 1, 10, 50, все
        anchors = [1, 10, 50, in_window]
    elif free_now < 20:
        # Близко к лимиту — показываем когда откроется ещё несколько
        anchors = [free_now + 1, free_now + 10, in_window]
    else:
        anchors = []

    for n in anchors:
        if n <= 0 or n > in_window:
            continue
        # n-й слот освобождается через 24ч после (n-1)-го отклика в окне
        slot_open_ts = sorted_ts[n - 1] + dt.timedelta(hours=24)
        if slot_open_ts > now:
            free_slot_times.append((n, slot_open_ts))
    # Убираем дубликаты по n
    seen_n = set()
    free_slot_times = [(n, t) for n, t in free_slot_times if not (n in seen_n or seen_n.add(n))]

    return {
        "in_window": in_window,
        "free_now": free_now,
        "calendar_today": calendar_today,
        "window_start": window_start,
        "oldest_in_window": oldest_in_window,
        "sorted_ts_in_window": sorted_ts,
        "full_reset_at": full_reset_at,
        "free_slot_times": free_slot_times,
    }


def predict_slots_at(limits_state, target_time):
    """Сколько слотов будет свободно к моменту target_time.

    Учитывает, что отклики «выпадают» из окна через 24ч после отправки.
    """
    if target_time is None:
        return limits_state["free_now"]
    sorted_ts = limits_state["sorted_ts_in_window"]
    # Те отклики, которые к моменту target_time выйдут за пределы 24ч-окна
    cutoff = target_time - dt.timedelta(hours=24)
    expired_by_target = sum(1 for ts in sorted_ts if ts < cutoff)
    in_window_at_target = len(sorted_ts) - expired_by_target
    return max(0, HH_DAILY_LIMIT - in_window_at_target)


def format_limits_block(items, now, next_cron_at=None):
    """Возвращает текстовый блок с информацией о лимитах HH.
    Один формат — используется и в /status, и в /next."""
    st = compute_limits_state(items, now)

    lines = []
    lines.append("<b>📊 Лимит HH</b> (200 откликов за 24 часа)")
    lines.append("")

    # Основная сводка
    bar_filled = st["in_window"]
    lines.append(f"За последние 24ч: <b>{bar_filled} из {HH_DAILY_LIMIT}</b>")
    lines.append(f"Свободно сейчас: <b>{st['free_now']}</b>")

    today_str = now.strftime("%d.%m")
    today_word = plural_ru(st["calendar_today"], ("отклик", "отклика", "откликов"))
    lines.append(f"За календарный день ({today_str}): {st['calendar_today']} {today_word}")

    # Когда освободятся слоты — показываем только если близко к лимиту
    if st["free_slot_times"]:
        lines.append("")
        lines.append("<b>⏳ Когда освободятся слоты:</b>")
        for n, t in st["free_slot_times"]:
            delta = t - now
            slot_word = plural_ru(n, ("слот", "слота", "слотов"))
            if n == HH_DAILY_LIMIT or (st["in_window"] >= HH_DAILY_LIMIT and n == st["in_window"]):
                label = f"Все {n}"
            else:
                label = f"{n} {slot_word}"
            lines.append(f"  • {label}: через {fmt_timedelta(delta)} ({fmt_dt_short(t)})")

    # Полный сброс окна (когда все 200 будут доступны)
    if st["full_reset_at"] and st["full_reset_at"] > now:
        # Показываем только если ещё не показано в free_slot_times
        already_shown = any(n == st["in_window"] for n, _ in st["free_slot_times"])
        if not already_shown and st["in_window"] >= HH_DAILY_LIMIT * 0.5:
            delta = st["full_reset_at"] - now
            lines.append("")
            lines.append(f"🔄 Полный сброс окна: через {fmt_timedelta(delta)} ({fmt_dt_short(st['full_reset_at'])})")

    # Что будет к следующему cron-прогону
    if next_cron_at:
        slots_at_cron = predict_slots_at(st, next_cron_at)
        lines.append("")
        lines.append(f"🤖 К следующему прогону ({fmt_dt_short(next_cron_at)}):")
        if slots_at_cron > 0:
            slot_word = plural_ru(slots_at_cron, ("слот", "слота", "слотов"))
            lines.append(f"   будет свободно ~<b>{slots_at_cron}</b> {slot_word}")
        else:
            lines.append("   слотов не будет, прогон отработает вхолостую")

    return "\n".join(lines)


def cmd_next():
    """Следующий прогон. Строго по шаблону."""
    hours, source = parse_apply_cron_hours()
    nxt = next_cron_run(hours)

    items = parse_log_applies()
    now = now_msk()
    st = compute_limits_state(items, now)

    lines = []

    # Ближайший cron
    if is_paused():
        lines.append("⏸ <b>Стоит пауза.</b> Запланированные прогоны пропускаются до возобновления.")
    elif nxt:
        delta = nxt - now
        lines.append(f"📅 Ближайший прогон: <b>{fmt_dt(nxt)}</b> (через {fmt_timedelta(delta)})")
    else:
        lines.append("⚠️ Не удалось вычислить следующий прогон.")

    # Прогноз на cron
    if nxt and not is_paused():
        slots_at_cron = predict_slots_at(st, nxt)
        lines.append("")
        lines.append(f"🤖 К следующему прогону ({fmt_dt_short(nxt)}):")
        if slots_at_cron > 0:
            slot_word = plural_ru(slots_at_cron, ("слот", "слота", "слотов"))
            lines.append(f"   будет свободно ~<b>{slots_at_cron}</b> {slot_word}")
        else:
            lines.append("   слотов не будет, прогон отработает вхолостую")

    # Полный сброс окна
    if st["full_reset_at"] and st["full_reset_at"] > now and st["in_window"] > 0:
        delta = st["full_reset_at"] - now
        lines.append("")
        lines.append(f"🔄 Полный сброс всех лимитов через {fmt_timedelta(delta)} ({fmt_dt_short(st['full_reset_at'])})")

    # Текущее время — в самом конце
    lines.append("")
    lines.append(f"🕒 Сейчас: <b>{fmt_dt(now)}</b>")

    return "\n".join(lines)


def cmd_reply_employers(chat_id):
    """`reply-employers --use-ai`: ответы в чатах с работодателями.

    Без --use-ai утилита просит текст ответа в интерактивном режиме, поэтому
    из бота команда доступна только при включённой генерации."""
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    account = profile.get("hh_account", "main")
    ai = profiles_lib.get_ai(profile)
    if not ai["enabled"]:
        return ("❌ Нужна генерация писем: «🤖 Настройки AI» → «⚡ Письма».\n"
                "Без неё утилита ждёт текст ответа в интерактивном режиме.")
    cfg = read_ai_config(account)
    if not (cfg["api_key"] and cfg["base_url"]):
        return "❌ Не задан ключ или endpoint: «🤖 Настройки AI» → «🔐 Доступ к AI»."

    args = ["hh-applicant-tool", "--profile", account, "reply-employers", "--use-ai"]
    resume_id = (profile.get("resume_id") or "").strip()
    if resume_id:
        args.extend(["--resume-id", resume_id])
    if ai["dry_run"]:
        args.append("--dry-run")

    def runner():
        try:
            res = subprocess.run(args, capture_output=True, text=True, timeout=900)
            output = ((res.stdout or "") + (res.stderr or ""))[-1500:]
            head = "✅ Ответы отправлены." if res.returncode == 0 else f"⚠️ Код {res.returncode}"
            send(chat_id, f"{head}\n\n<pre>{html.escape(output or 'нет вывода')}</pre>")
        except subprocess.TimeoutExpired:
            send(chat_id, "⚠️ Команда не завершилась за 15 минут.")
        except FileNotFoundError:
            send(chat_id, "⚠️ hh-applicant-tool не найден в PATH.")
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка: {html.escape(str(e))}")

    threading.Thread(target=runner, daemon=True).start()
    mode = " (тестовый прогон)" if ai["dry_run"] else ""
    return f"🚀 Отвечаю работодателям{mode}. Результат пришлю по завершении."


def cmd_cleanup(chat_id):
    """Запускает `hh-applicant-tool clear-negotiations -d`.
    Удаляет переговоры со статусом 'discard' (отказы)."""

    def runner():
        try:
            send(chat_id, "Начато удаление отказов.")
            _, profile = profiles_lib.get_active_profile()
            hh_account = (profile or {}).get("hh_account", "main")
            res = subprocess.run(
                ["hh-applicant-tool", "--profile", hh_account,
                 "clear-negotiations", "-d"],
                capture_output=True, text=True, timeout=300,
            )
            output = (res.stdout or "") + (res.stderr or "")
            tail = output[-1500:] if len(output) > 1500 else output

            if res.returncode == 0:
                msg = f"✅ Удаление отказов завершено.\n\n<pre>{html.escape(tail or 'OK')}</pre>"
            else:
                msg = f"⚠️ Завершено с кодом {res.returncode}\n\n<pre>{html.escape(tail or 'нет вывода')}</pre>"
            send(chat_id, msg)
        except subprocess.TimeoutExpired:
            send(chat_id, "⚠️ Команда не завершилась за 5 минут.")
        except FileNotFoundError:
            send(chat_id, "⚠️ hh-applicant-tool не найден в PATH.\nЭта команда работает только внутри основного контейнера. См. «📜 Лог» для деталей.")
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка: {html.escape(str(e))}")

    threading.Thread(target=runner, daemon=True).start()
    return "🚀 Запущено в фоне. Результат пришлёт по завершении."


def cmd_log():
    """Последние 30 строк лога утилиты."""
    if not get_active_tool_log().exists():
        return "Лог пуст или не создан."
    try:
        with get_active_tool_log().open("r", errors="ignore") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 30_000))
            tail = f.read()
        lines = tail.splitlines()[-30:]
        out = "\n".join(lines)
        if len(out) > 3500:
            out = out[-3500:]
        return f"📜 <b>Хвост лога:</b>\n\n<pre>{html.escape(out)}</pre>"
    except Exception as e:
        return f"⚠️ {html.escape(str(e))}"


def is_hh_limit_hit_recently():
    """Смотрит последние ~50 КБ лога и проверяет, не было ли там
    в последний час сообщения об исчерпании дневного лимита HH.
    Возвращает (hit: bool, ts: datetime or None)."""
    if not get_active_tool_log().exists():
        return (False, None)
    try:
        with get_active_tool_log().open("r", errors="ignore") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 50_000))
            tail = f.read()
    except Exception:
        return (False, None)

    # Ищем последнее упоминание лимита
    pattern = re.compile(
        r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),\d+\s+-\s+\w+\s+-\s+"
        r"(?:Лимит откликов.*исчерпан|Достигли лимита на отклики)",
        re.MULTILINE,
    )
    matches = list(pattern.finditer(tail))
    if not matches:
        return (False, None)
    try:
        ts = dt.datetime.strptime(matches[-1].group(1), "%Y-%m-%d %H:%M:%S")
    except Exception:
        return (True, None)

    # Считаем "недавним" если в последние 12 часов
    if (now_msk() - ts) > dt.timedelta(hours=12):
        return (False, ts)
    return (True, ts)


def parse_log_applies():
    """Парсит config/log.txt и возвращает список всех успешных откликов.
    Каждый элемент: dict(ts: datetime, vid: str).
    Только уникальные vacancy_id (если бот ретраил — учитываем один раз)."""
    if not get_active_tool_log().exists():
        return []

    # Формат строки:
    # 2026-04-23 13:08:15,432 - DEBUG - 201 POST https://api.hh.ru/negotiations with params: {'resume_id': '...', 'vacancy_id': '132405587', ...}
    pattern = re.compile(
        r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),\d+\s+-\s+\w+\s+-\s+"
        r"201 POST https://api\.hh\.ru/negotiations with params:\s*\{[^}]*"
        r"'vacancy_id':\s*'(\d+)'"
    )

    seen = set()
    items = []
    try:
        with get_active_tool_log().open("r", errors="ignore") as f:
            for line in f:
                m = pattern.search(line)
                if not m:
                    continue
                vid = m.group(2)
                if vid in seen:
                    continue
                seen.add(vid)
                try:
                    ts = dt.datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")
                except Exception:
                    continue
                items.append({"ts": ts, "vid": vid})
    except Exception as e:
        print(f"parse_log_applies failed: {e}", file=sys.stderr)
    return items


def fetch_vacancy_brief(vid):
    """Краткая инфа по вакансии (name, employer) через HH API.
    Токен берётся для активного HH-аккаунта. С кэшем в памяти процесса."""
    if not hasattr(fetch_vacancy_brief, "_cache"):
        fetch_vacancy_brief._cache = {}
    cache = fetch_vacancy_brief._cache
    if vid in cache:
        return cache[vid]

    token = _read_token_for_account()
    if not token:
        cache[vid] = ("", "")
        return cache[vid]

    req = urllib.request.Request(
        f"https://api.hh.ru/vacancies/{vid}",
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "hh-applicant-tool/bot",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        name = (data.get("name") or "").strip()
        employer = ((data.get("employer") or {}).get("name") or "").strip()
        result = (name, employer)
    except Exception as e:
        print(f"fetch_vacancy_brief failed for {vid}: {e}", file=sys.stderr)
        result = ("", "")

    cache[vid] = result
    if len(cache) > 300:
        for k in list(cache.keys())[:100]:
            cache.pop(k, None)
    return result


def cmd_stats(today_only):
    items = parse_log_applies()
    if not items:
        return "📊 Откликов пока нет в логе."

    if today_only:
        today = now_msk().date()
        items = [x for x in items if x["ts"].date() == today]
        label = "сегодня"
    else:
        label = "всё время"

    total = len(items)
    lines = [f"<b>📊 Статистика ({label})</b>",
             f"Откликов: <b>{total}</b>"]

    if total > 0 and not today_only:
        first = min(x["ts"] for x in items)
        last = max(x["ts"] for x in items)
        lines.append(f"Первый: {fmt_dt(first)}")
        lines.append(f"Последний: {fmt_dt(last)}")

        # Разбивка по дням
        by_day = Counter(x["ts"].date().isoformat() for x in items)
        if len(by_day) <= 14:
            lines.append("\n<b>По дням:</b>")
            for day in sorted(by_day, reverse=True)[:14]:
                lines.append(f"• {day}: <b>{by_day[day]}</b>")
        else:
            lines.append("\n<b>Последние 7 дней:</b>")
            for day in sorted(by_day, reverse=True)[:7]:
                lines.append(f"• {day}: <b>{by_day[day]}</b>")

    return "\n".join(lines)


def cmd_recent():
    items = parse_log_applies()
    if not items:
        return "🕒 Откликов пока нет."

    recent = sorted(items, key=lambda x: x["ts"], reverse=True)[:10]

    lines = ["<b>🕒 Последние 10 откликов</b>"]
    for r in recent:
        vid = r["vid"]
        ts = fmt_dt(r["ts"])
        name, employer = fetch_vacancy_brief(vid)
        if name:
            title = html.escape(name)
            if employer:
                title += f" — {html.escape(employer)}"
        else:
            title = f"Вакансия {vid}"
        lines.append(
            f"\n• <b>{title}</b>\n"
            f"  🕒 {ts}\n"
            f"  🔗 https://hh.ru/vacancy/{vid}"
        )
    return "\n".join(lines)


POSITIVE_STATES = ("invitation", "phone_interview", "assessment", "offer")


def cmd_invites():
    """Актуальные приглашения по активному аккаунту — из API, а не из лога."""
    data = hh_get("/negotiations?per_page=100")
    if not data:
        return "❌ Нет доступа к API. Проверь авторизацию аккаунта."
    items = list(data.get("items", []) or [])
    pages = min(int(data.get("pages") or 1), 5)
    for page in range(1, pages):
        more = hh_get(f"/negotiations?per_page=100&page={page}")
        items += (more or {}).get("items", []) or []

    buckets = {state: [] for state in POSITIVE_STATES}
    for it in items:
        state = (it.get("state") or {}).get("id")
        if state in buckets:
            buckets[state].append(it)

    total = sum(len(v) for v in buckets.values())
    if not total:
        return ("🎉 <b>Приглашения</b>\n\nПока пусто. "
                "Как только статус отклика сменится, уведомление придёт само.")

    lines = [f"🎉 <b>Актуальные приглашения</b> ({total})"]
    for state in POSITIVE_STATES:
        group = buckets[state]
        if not group:
            continue
        lines.append(f"\n<b>{html.escape(state_label(state))}</b> — {len(group)}")
        for it in sorted(group, key=lambda x: x.get("updated_at") or "", reverse=True)[:15]:
            vacancy = it.get("vacancy") or {}
            name = vacancy.get("name") or "—"
            employer = (vacancy.get("employer") or {}).get("name") or "—"
            url = vacancy.get("alternate_url") or ""
            updated = (it.get("updated_at") or "")[:10]
            title = f"<a href=\"{url}\">{html.escape(name)}</a>" if url else html.escape(name)
            mark = "🆕 " if it.get("has_updates") else ""
            lines.append(f"— {mark}{title} @ {html.escape(employer)} ({updated})")
    lines.append("\n💬 Переписка: hh.ru/applicant/negotiations")
    return "\n".join(lines)


def cmd_statuses():
    """Берёт текущие статусы откликов через HH API (не из локальной БД)."""
    data = hh_get("/negotiations?per_page=100")
    items = list(data.get("items", []) or [])
    pages = min(int(data.get("pages") or 1), 5)
    for page in range(1, pages):
        more = hh_get(f"/negotiations?per_page=100&page={page}")
        items += more.get("items", []) or []

    if not items:
        return "Откликов нет (или нет доступа к API)."

    counter = Counter()
    recent = []
    for it in items:
        state = (it.get("state") or {}).get("id") or (it.get("state") or {}).get("name") or "—"
        counter[state] += 1
        recent.append((
            (it.get("vacancy") or {}).get("name") or "—",
            ((it.get("vacancy") or {}).get("employer") or {}).get("name") or "—",
            state,
            (it.get("updated_at") or "")[:10],
        ))

    lines = [f"<b>📋 Статусы откликов на HH</b> (всего: {sum(counter.values())})"]
    for st, n in counter.most_common():
        lines.append(f"• {html.escape(state_label(st))}: <b>{n}</b>")

    lines.append("\n<b>Последние 10:</b>")
    for name, emp, st, upd in recent[:10]:
        lines.append(
            f"— <i>{html.escape(name)}</i> @ {html.escape(emp)} → "
            f"{html.escape(state_label(st))} ({upd})"
        )
    return "\n".join(lines)


# =================== Маршрутизация (кнопочный UI) ===================

def _active_profile_label():
    """Короткое имя активного профиля для заголовков."""
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "(нет профиля)"
    return profile.get("display_name") or pid


def cmd_profile_remove_active():
    """Удаляет активный профиль и его файл письма (после миграции файл
    у каждого профиля свой, поэтому удаление безопасно)."""
    items = profiles_lib.list_profiles()
    if len(items) <= 1:
        return "⚠️ Нельзя удалить последний профиль."
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    display = profile.get("display_name") or pid
    letter_name = profile.get("letter")
    try:
        profiles_lib.remove_profile(pid)
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"
    if letter_name:
        try:
            (profiles_lib.LETTERS_DIR / Path(letter_name).name).unlink()
        except FileNotFoundError:
            pass
        except Exception:
            pass
    return f"✅ Профиль «{html.escape(display)}» удалён вместе с письмом."


# =================== Инлайн-меню («🎛 Меню») ===================
# Меню: {"title": str, "rows": [[(label, callback_data), ...], ...]}.
# callback_data: "menu:<name>", "switch:<pid>", "del:yes", "cmd:<command>".

def build_menu_main():
    label = _active_profile_label()
    return {
        "title": f"<b>🎛 Меню</b>\nАктивный профиль: <b>{html.escape(label)}</b>",
        "rows": [
            [("📊 Просмотр", "menu:view"), ("🎛 Управление", "menu:ctl")],
            [("👤 Профиль", "menu:profile"), ("❓ Справка", "menu:help")],
        ],
    }


def build_menu_view():
    return {
        "title": "<b>📊 Просмотр</b>",
        "rows": [
            [("⚙️ Статус", "cmd:/status"), ("⏰ Лимит", "cmd:/next")],
            [("📅 Сегодня", "cmd:/stats_today"), ("📊 За всё", "cmd:/stats")],
            [("🕒 Последние", "cmd:/recent"), ("🎯 На HH", "cmd:/statuses")],
            [("🎉 Приглашения", "cmd:/invites")],
            [("📜 Лог", "cmd:/log")],
            [("⬅️ Назад", "menu:main")],
        ],
    }


def build_menu_ctl():
    return {
        "title": "<b>🎛 Управление</b>",
        "rows": [
            [("▶️ Запустить", "cmd:/run"), ("⏸ Пауза", "cmd:/pause")],
            [("⏯ Возобновить", "cmd:/resume")],
            [("💬 Ответить работодателям", "cmd:/reply")],
            [("🧹 Удалить отказы", "cmd:/cleanup")],
            [("♻️ Сбросить пропущенные", "cmd:/clear_skipped")],
            [("💾 Бэкап в чат", "cmd:/backup")],
            [("⬅️ Назад", "menu:main")],
        ],
    }


def build_menu_profile():
    label = _active_profile_label()
    return {
        "title": f"<b>👤 Профиль: {html.escape(label)}</b>",
        "rows": [
            [("📝 Письмо", "cmd:/letter"), ("✏️ Изменить", "cmd:/letter_set")],
            [("🔍 Запрос", "cmd:/search"), ("✏️ Изменить", "cmd:/search_set")],
            [("🌍 Регион", "cmd:/area"), ("📄 Резюме", "menu:resume")],
            [("🔎 Фильтры поиска", "menu:filters")],
            [("🤖 Настройки AI", "menu:ai")],
            [("🏷 Переименовать", "cmd:/profile_rename")],
            [("🔑 Авторизовать HH", "cmd:/auth")],
            [("⟳ Сменить", "menu:switch"), ("➕ Создать", "cmd:/profile_add")],
            [("📋 Список", "cmd:/profiles"), ("🗑 Удалить", "menu:del")],
            [("⬅️ Назад", "menu:main")],
        ],
    }


AI_FILTER_TITLES = {
    "": "выключен",
    "heavy": "heavy",
    "light": "light",
    "custom": "custom",
}


def _ai_flag(value):
    return "вкл" if value else "выкл"


def _ai_preview(text, limit=40):
    """Короткая выжимка промпта для подписи кнопки."""
    text = (text or "").strip().replace("\n", " ")
    if not text:
        return "по умолчанию"
    return text[:limit] + "…" if len(text) > limit else text


def build_menu_ai():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return {"title": "❌ Нет активного профиля.", "rows": [[("⬅️ Назад", "menu:profile")]]}
    ai = profiles_lib.get_ai(profile)
    label = _active_profile_label()
    warn = ""
    if ai["filter"] == "custom" and not ai["filter_prompt"].strip():
        warn = "\n⚠️ Режим <b>custom</b> без промпта — рассылка не запустится."
    title = (
        f"🤖 <b>AI профиля «{html.escape(label)}»</b>\n"
        f"Письма: <b>{_ai_flag(ai['enabled'])}</b>, "
        f"фильтр: <b>{AI_FILTER_TITLES.get(ai['filter'], ai['filter'])}</b>, "
        f"тест-прогон: <b>{_ai_flag(ai['dry_run'])}</b>{warn}"
    )
    return {
        "title": title,
        "rows": [
            [(f"⚡ Письма: {_ai_flag(ai['enabled'])}", "ai:toggle")],
            [(f"🎯 Фильтр: {AI_FILTER_TITLES.get(ai['filter'], ai['filter'])}", "menu:ai_filter")],
            [("✏️ Промпт фильтра", "cmd:/ai_filter_prompt")],
            [("✏️ Промпт письма", "cmd:/ai_message_prompt")],
            [("🧠 Роль модели", "cmd:/ai_system_prompt")],
            [(f"⏱ Лимит: {ai['rate_limit']}/мин", "cmd:/ai_rate")],
            [(f"🧪 Тест-прогон: {_ai_flag(ai['dry_run'])}", "ai:dry")],
            [("🔐 Доступ к AI", "menu:ai_access")],
            [("⬅️ Назад", "menu:profile")],
        ],
    }


def build_menu_ai_filter():
    _, profile = profiles_lib.get_active_profile()
    current = profiles_lib.get_ai(profile)["filter"] if profile else ""
    options = [
        ("", "🚫 Выключен"),
        ("light", "🪶 light — название и навыки"),
        ("heavy", "🧱 heavy — вакансия и резюме"),
        ("custom", "🎛 custom — свой промпт"),
    ]
    rows = [[(("✅ " if mode == current else "") + text, f"aifilter:{mode}")]
            for mode, text in options]
    rows.append([("⬅️ Назад", "menu:ai")])
    return {
        "title": ("🎯 <b>AI-фильтр вакансий</b>\n"
                  "Модель оценивает вакансию до отклика. <b>light</b> дешевле и быстрее, "
                  "<b>heavy</b> точнее и дороже, <b>custom</b> работает по вашему промпту."),
        "rows": rows,
    }


AI_PROMPT_FIELDS = {
    "/ai_filter_prompt": ("filter_prompt", "промпт AI-фильтра",
                          "Критерии, по которым модель отсеивает вакансии. "
                          "Работает только в режиме <b>custom</b>."),
    "/ai_message_prompt": ("message_prompt", "промпт сопроводительного письма",
                           "Что именно генерировать. Пусто — дефолт утилиты "
                           "(письмо на 5–7 предложений)."),
    "/ai_system_prompt": ("system_prompt", "роль модели",
                          "Системный промпт для генерации писем. Пусто — дефолт утилиты."),
}


def cmd_ai_prompt_edit(command):
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    field, title, hint = AI_PROMPT_FIELDS[command]
    current = profiles_lib.get_ai(profile)[field]
    PENDING["action"] = f"ai_set:{field}"
    body = f"<pre>{html.escape(current)}</pre>" if current.strip() else "<i>не задан</i>"
    return (f"✏️ <b>Правка: {title}</b>\n{hint}\n\nСейчас:\n{body}\n\n"
            "Пришли новый текст <b>одним сообщением</b>.\n"
            "«-» — сбросить на значение по умолчанию, /cancel — отмена.")


def cmd_ai_rate_edit():
    _, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    PENDING["action"] = "ai_set:rate_limit"
    return (f"⏱ <b>Лимит запросов к AI</b>\nСейчас: <b>{profiles_lib.get_ai(profile)['rate_limit']}</b> в минуту.\n\n"
            "Пришли число (1–600). Дефолт утилиты — 40. /cancel — отмена.")


def cmd_ai_save(field, text):
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        PENDING["action"] = None
        return "❌ Нет активного профиля."
    text = (text or "").strip()
    try:
        if field == "rate_limit":
            try:
                value = int(text)
            except ValueError:
                return "⚠️ Нужно целое число. Ещё раз или /cancel."
            if not 1 <= value <= 600:
                return "⚠️ Допустимый диапазон — от 1 до 600."
            profiles_lib.update_ai(pid, rate_limit=value)
            PENDING["action"] = None
            return f"✅ Лимит запросов к AI: <b>{value}</b> в минуту."
        if text == "-":
            text = ""
        if len(text) > 4000:
            return "⚠️ Слишком длинный промпт (максимум 4000 символов)."
        profiles_lib.update_ai(pid, **{field: text})
        PENDING["action"] = None
        title = next(t for _, (f, t, _) in AI_PROMPT_FIELDS.items() if f == field)
        return f"✅ Обновлено: {title}." if text else f"✅ Сброшено на умолчание: {title}."
    except Exception as e:
        PENDING["action"] = None
        return f"⚠️ Ошибка сохранения: {html.escape(str(e))}"


# =================== AI-конфигурация HH-аккаунта ===================
# Ключ, endpoint и модель лежат не в profiles.json, а в config.json аккаунта,
# отдельными секциями под каждую задачу. Читаем файл напрямую, пишем через CLI,
# чтобы не спорить с утилитой за формат конфига.
AI_SECTION_COVER = "openai_cover_letter"
AI_SECTION_FILTER = "openai_vacancy_filter"
AI_SECTION_CAPTCHA = "openai_captcha"
AI_SECTIONS = (AI_SECTION_COVER, AI_SECTION_FILTER, AI_SECTION_CAPTCHA)

AI_ENDPOINTS = [
    ("OpenAI", "https://api.openai.com/v1/chat/completions"),
    ("OpenRouter", "https://openrouter.ai/api/v1/chat/completions"),
    ("Ollama", "http://localhost:11434/v1/chat/completions"),
]


def _mask_secret(value):
    value = (value or "").strip()
    if not value:
        return ""
    return value[:6] + "…" + value[-4:] if len(value) > 14 else "…" * 3


def read_account_config(hh_account):
    path = CONFIG_DIR / hh_account / "config.json"
    if not path.is_file():
        path = CONFIG_DIR / "config.json"
    try:
        with path.open(encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def read_ai_config(hh_account):
    """Сводка AI-настроек аккаунта: что задано в секции писем + прокси."""
    cfg = read_account_config(hh_account)
    cover = cfg.get(AI_SECTION_COVER) or {}
    captcha = cfg.get(AI_SECTION_CAPTCHA) or {}
    return {
        "api_key": cover.get("api_key") or "",
        "base_url": cover.get("base_url") or "",
        "model": cover.get("model") or "",
        "proxy_url": (cfg.get("openai") or {}).get("proxy_url") or "",
        "captcha": bool(captcha.get("api_key")),
    }


def hh_config_set(hh_account, key, value):
    """`hh-applicant-tool --profile X config --set key value`."""
    try:
        res = subprocess.run(
            ["hh-applicant-tool", "--profile", hh_account, "config", "--set", key, value],
            capture_output=True, text=True, timeout=60,
        )
    except FileNotFoundError:
        return False, "hh-applicant-tool не найден в PATH"
    except subprocess.TimeoutExpired:
        return False, "команда не завершилась за 60 секунд"
    except Exception as e:
        return False, str(e)
    if res.returncode != 0:
        return False, ((res.stderr or res.stdout or "").strip() or f"код {res.returncode}")
    return True, ""


def hh_config_unset(hh_account, key):
    try:
        res = subprocess.run(
            ["hh-applicant-tool", "--profile", hh_account, "config", "--unset", key],
            capture_output=True, text=True, timeout=60,
        )
        return res.returncode == 0, (res.stderr or "").strip()
    except Exception as e:
        return False, str(e)


def ai_config_apply(hh_account, field, value, sections=None):
    """Пишет одно поле сразу во все нужные секции. Возвращает список ошибок."""
    errors = []
    for section in (sections or (AI_SECTION_COVER, AI_SECTION_FILTER)):
        ok, err = hh_config_set(hh_account, f"{section}.{field}", value)
        if not ok:
            errors.append(f"{section}: {err}")
    return errors


def build_menu_ai_access():
    _, profile = profiles_lib.get_active_profile()
    if not profile:
        return {"title": "❌ Нет активного профиля.", "rows": [[("⬅️ Назад", "menu:ai")]]}
    account = profile.get("hh_account", "main")
    cfg = read_ai_config(account)
    endpoint = next((name for name, url in AI_ENDPOINTS if url == cfg["base_url"]),
                    cfg["base_url"] or "не задан")
    warn = "" if cfg["api_key"] and cfg["base_url"] else (
        "\n⚠️ Без ключа и endpoint рассылка с AI упадёт с «API-ключ не задан»."
    )
    return {
        "title": (f"🔐 <b>Доступ к AI</b>\nАккаунт HH: <b>{html.escape(account)}</b> — "
                  "настройки общие для всех его профилей.\n"
                  f"Ключ: <b>{_mask_secret(cfg['api_key']) or 'не задан'}</b>{warn}"),
        "rows": [
            [(f"🔑 Ключ: {'задан' if cfg['api_key'] else 'нет'}", "cmd:/ai_key")],
            [(f"🌐 Endpoint: {endpoint}", "menu:ai_endpoint")],
            [(f"🧠 Модель: {cfg['model'] or 'не задана'}", "cmd:/ai_model")],
            [(f"🕸 Прокси: {'задан' if cfg['proxy_url'] else 'нет'}", "cmd:/ai_proxy")],
            [(f"🖼 Капча через AI: {'вкл' if cfg['captcha'] else 'выкл'}", "aicfg:captcha")],
            [("⬅️ Назад", "menu:ai")],
        ],
    }


def build_menu_ai_endpoint():
    _, profile = profiles_lib.get_active_profile()
    current = read_ai_config((profile or {}).get("hh_account", "main"))["base_url"]
    rows = [[(("✅ " if url == current else "") + name, f"aiurl:{idx}")]
            for idx, (name, url) in enumerate(AI_ENDPOINTS)]
    rows.append([("✏️ Указать вручную", "cmd:/ai_base_url")])
    rows.append([("⬅️ Назад", "menu:ai_access")])
    return {
        "title": ("🌐 <b>Endpoint</b>\nУтилита требует полный URL метода chat/completions, "
                  "а не адрес сервера. Совместимые провайдеры подставляются кнопками ниже."),
        "rows": rows,
    }


AI_CONFIG_FIELDS = {
    "/ai_key": ("api_key", "API-ключ",
                "Ключ пишется в секции писем, фильтра и — если включена — капчи.\n"
                "Сообщение с ключом бот удалит из чата сразу после сохранения."),
    "/ai_model": ("model", "модель",
                  "Например <code>gpt-4o</code> или <code>gpt-4o-mini</code>. "
                  "Пусто — утилита возьмёт свою по умолчанию и напишет предупреждение."),
    "/ai_base_url": ("base_url", "endpoint",
                     "Полный URL, например <code>https://api.openai.com/v1/chat/completions</code>."),
    "/ai_proxy": ("proxy_url", "прокси для OpenAI",
                  "Отдельный прокси только для запросов к модели, "
                  "например <code>socks5://user:pass@host:1080</code>. «-» — убрать."),
}


def cmd_ai_config_edit(command):
    _, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    field, title, hint = AI_CONFIG_FIELDS[command]
    account = profile.get("hh_account", "main")
    current = read_ai_config(account).get(field, "")
    shown = _mask_secret(current) if field == "api_key" else (current or "")
    PENDING["action"] = f"aicfg:{field}"
    return (f"✏️ <b>{title}</b> для аккаунта <b>{html.escape(account)}</b>\n{hint}\n\n"
            f"Сейчас: <code>{html.escape(shown) if shown else 'не задано'}</code>\n\n"
            "Пришли значение одним сообщением. /cancel — отмена.")


def cmd_ai_config_save(field, text):
    _, profile = profiles_lib.get_active_profile()
    if not profile:
        PENDING["action"] = None
        return "❌ Нет активного профиля."
    account = profile.get("hh_account", "main")
    value = (text or "").strip()
    PENDING["action"] = None

    if field == "proxy_url":
        if value == "-":
            hh_config_unset(account, "openai.proxy_url")
            return "✅ Прокси для OpenAI убран."
        ok, err = hh_config_set(account, "openai.proxy_url", value)
        return "✅ Прокси сохранён." if ok else f"⚠️ Не сохранилось: {html.escape(err)}"

    if field == "base_url" and not value.startswith(("http://", "https://")):
        return "⚠️ Нужен полный URL со схемой http:// или https://. Ещё раз или /cancel."
    if field == "api_key" and len(value) < 8:
        return "⚠️ Ключ выглядит слишком коротким. Ещё раз или /cancel."

    sections = [AI_SECTION_COVER, AI_SECTION_FILTER]
    if read_ai_config(account)["captcha"]:
        sections.append(AI_SECTION_CAPTCHA)
    errors = ai_config_apply(account, field, value, sections)
    title = AI_CONFIG_FIELDS[next(k for k, v in AI_CONFIG_FIELDS.items() if v[0] == field)][1]
    if errors:
        return "⚠️ Не сохранилось:\n<pre>" + html.escape("\n".join(errors)) + "</pre>"
    return f"✅ Сохранено: {title} (секций: {len(sections)})."


# =================== Фильтры поиска ===================
FILTER_LABELS = {
    "experience": {"": "любой", "noExperience": "без опыта", "between1And3": "1–3 года",
                   "between3And6": "3–6 лет", "moreThan6": "более 6 лет"},
    "schedule": {"": "любой", "fullDay": "полный день", "shift": "сменный",
                 "flexible": "гибкий", "remote": "удалённый", "flyInFlyOut": "вахта"},
    "work_format": {"REMOTE": "удалённо", "HYBRID": "гибрид",
                    "ON_SITE": "в офисе", "FIELD_WORK": "разъездная"},
    "order_by": {"": "по умолчанию", "publication_time": "по дате", "salary_desc": "зарплата ↓",
                 "salary_asc": "зарплата ↑", "relevance": "по релевантности"},
}


def build_menu_filters():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return {"title": "❌ Нет активного профиля.", "rows": [[("⬅️ Назад", "menu:profile")]]}
    f = profiles_lib.get_filters(profile)
    formats = ", ".join(FILTER_LABELS["work_format"][v] for v in f["work_format"]) or "любой"
    banned = len(f["excluded_employer_ids"])
    return {
        "title": (f"🔎 <b>Фильтры поиска «{html.escape(_active_profile_label())}»</b>\n"
                  "Отсекают вакансии на стороне HH — до отклика и до вызова AI, "
                  "то есть бесплатно."),
        "rows": [
            [(f"💼 Опыт: {FILTER_LABELS['experience'][f['experience']]}", "menu:f_exp")],
            [(f"🕘 График: {FILTER_LABELS['schedule'][f['schedule']]}", "menu:f_sched")],
            [(f"🏠 Формат: {formats}", "menu:f_format")],
            [(f"💰 Зарплата от: {f['salary'] or 'любой'}", "cmd:/f_salary")],
            [(f"💵 Только с зарплатой: {_ai_flag(f['only_with_salary'])}", "flt:only_with_salary")],
            [(f"📅 Период: {str(f['period']) + ' дн' if f['period'] else 'любой'}", "cmd:/f_period")],
            [(f"↕️ Сортировка: {FILTER_LABELS['order_by'][f['order_by']]}", "menu:f_order")],
            [(f"🧪 Пропускать тесты: {_ai_flag(f['skip_tests'])}", "flt:skip_tests")],
            [(f"📧 Письмо на email: {_ai_flag(f['send_email'])}", "flt:send_email")],
            [(f"🚫 Чёрный список: {banned}", "menu:f_banned")],
            [("⬅️ Назад", "menu:profile")],
        ],
    }


def _build_filter_picker(field, title, hint):
    _, profile = profiles_lib.get_active_profile()
    current = profiles_lib.get_filters(profile)[field] if profile else ""
    rows = [[(("✅ " if value == current else "") + label, f"fset:{field}:{value}")]
            for value, label in FILTER_LABELS[field].items()]
    rows.append([("⬅️ Назад", "menu:filters")])
    return {"title": f"<b>{title}</b>\n{hint}", "rows": rows}


def build_menu_f_exp():
    return _build_filter_picker("experience", "💼 Опыт работы",
                                "Соответствует фильтру опыта в поиске HH.")


def build_menu_f_sched():
    return _build_filter_picker("schedule", "🕘 График работы",
                                "Старый фильтр HH; для удалёнки надёжнее «Формат работы».")


def build_menu_f_order():
    return _build_filter_picker("order_by", "↕️ Сортировка выдачи",
                                "«По дате» полезна: свежий отклик рекрутер видит первым.")


def build_menu_f_format():
    _, profile = profiles_lib.get_active_profile()
    current = profiles_lib.get_filters(profile)["work_format"] if profile else []
    rows = [[(("✅ " if value in current else "") + label, f"fmt:{value}")]
            for value, label in FILTER_LABELS["work_format"].items()]
    rows.append([("⬅️ Назад", "menu:filters")])
    return {"title": ("🏠 <b>Формат работы</b>\nМожно отметить несколько. "
                      "Пусто — фильтр не передаётся."), "rows": rows}


def build_menu_f_banned():
    _, profile = profiles_lib.get_active_profile()
    ids = profiles_lib.get_filters(profile)["excluded_employer_ids"] if profile else []
    rows = [[(f"🗑 {eid}", f"unban:{eid}")] for eid in ids[:20]]
    if ids:
        rows.append([("🧹 Очистить список", "unban:all")])
    rows.append([("⬅️ Назад", "menu:filters")])
    return {
        "title": ("🚫 <b>Чёрный список работодателей</b>\n"
                  + (f"В списке: {len(ids)}. Их вакансии исключаются из выдачи."
                     if ids else "Пуст. Работодатели добавляются кнопкой под уведомлением об отклике.")),
        "rows": rows,
    }


FILTER_NUMERIC = {
    "/f_salary": ("salary", "💰 Зарплата от",
                  "Минимальная зарплата в рублях. 0 — не фильтровать."),
    "/f_period": ("period", "📅 Период публикации",
                  "Искать вакансии за последние N дней. 0 — без ограничения."),
}


def cmd_filter_number_edit(command):
    _, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    field, title, hint = FILTER_NUMERIC[command]
    PENDING["action"] = f"flt_num:{field}"
    return (f"✏️ <b>{title}</b>\n{hint}\n\n"
            f"Сейчас: <b>{profiles_lib.get_filters(profile)[field]}</b>\n\n"
            "Пришли число. /cancel — отмена.")


def cmd_filter_number_save(field, text):
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        PENDING["action"] = None
        return "❌ Нет активного профиля."
    try:
        value = int((text or "").strip())
    except ValueError:
        return "⚠️ Нужно целое число. Ещё раз или /cancel."
    if value < 0 or value > 10_000_000:
        return "⚠️ Значение вне разумного диапазона."
    profiles_lib.update_filters(pid, **{field: value})
    PENDING["action"] = None
    title = FILTER_NUMERIC[next(k for k, v in FILTER_NUMERIC.items() if v[0] == field)][1]
    return f"✅ {title}: <b>{value or 'не задано'}</b>"


def cmd_clear_skipped(chat_id):
    """`clear-skipped`: сброс списка пропущенных вакансий."""
    _, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    account = profile.get("hh_account", "main")

    def runner():
        try:
            res = subprocess.run(
                ["hh-applicant-tool", "--profile", account, "clear-skipped"],
                capture_output=True, text=True, timeout=300,
            )
            out = ((res.stdout or "") + (res.stderr or ""))[-1000:]
            head = "✅ Список пропущенных очищен." if res.returncode == 0 else f"⚠️ Код {res.returncode}"
            send(chat_id, f"{head}\n\n<pre>{html.escape(out or 'нет вывода')}</pre>")
        except FileNotFoundError:
            send(chat_id, "⚠️ hh-applicant-tool не найден в PATH.")
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка: {html.escape(str(e))}")

    threading.Thread(target=runner, daemon=True).start()
    return "🚀 Чищу список пропущенных вакансий."


def cmd_backup(chat_id):
    """Архив config/, profiles.json и letters/ отдельным файлом в чат."""
    def runner():
        try:
            res = subprocess.run([sys.executable, str(profiles_lib.APP_DIR / "backup.py")],
                                 capture_output=True, text=True, timeout=600)
            if res.returncode != 0:
                out = ((res.stderr or "") + (res.stdout or ""))[-800:]
                send(chat_id, f"⚠️ Бэкап не собрался:\n<pre>{html.escape(out)}</pre>")
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка бэкапа: {html.escape(str(e))}")

    threading.Thread(target=runner, daemon=True).start()
    return "💾 Собираю бэкап, файл придёт следующим сообщением."


def cmd_ban_employer(chat_id, vacancy_id):
    """Добавляет работодателя вакансии в чёрный список активного профиля."""
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        return "❌ Нет активного профиля."
    data = hh_get(f"/vacancies/{vacancy_id}")
    employer = (data or {}).get("employer") or {}
    eid = str(employer.get("id") or "")
    name = employer.get("name") or f"ID {eid}"
    if not eid.isdigit():
        return "⚠️ Не удалось определить работодателя через API."
    try:
        added = profiles_lib.ban_employer(pid, eid)
    except Exception as e:
        return f"⚠️ Ошибка: {html.escape(str(e))}"
    if not added:
        return f"ℹ️ {html.escape(name)} уже в чёрном списке."
    return (f"🚫 <b>{html.escape(name)}</b> добавлен в чёрный список профиля "
            f"«{html.escape(_active_profile_label())}». "
            "Его вакансии больше не попадут в выдачу.")


def build_menu_switch():
    active_pid, _ = profiles_lib.get_active_profile()
    rows = []
    for pid, p in profiles_lib.list_profiles():
        display = p.get("display_name") or pid
        marker = "▶️ " if pid == active_pid else ""
        rows.append([(f"{marker}{display}", f"switch:{pid}")])
    rows.append([("⬅️ Назад", "menu:profile")])
    return {"title": "<b>⟳ Сменить профиль</b>\nВыбери активный профиль:", "rows": rows}


def build_menu_del():
    if len(profiles_lib.list_profiles()) <= 1:
        return {
            "title": "🗑 <b>Удаление профиля</b>\n⚠️ Нельзя удалить последний профиль.",
            "rows": [[("⬅️ Назад", "menu:profile")]],
        }
    label = _active_profile_label()
    return {
        "title": (
            f"🗑 <b>Удалить активный профиль «{html.escape(label)}»?</b>\n"
            "Профиль и его файл письма будут удалены. Действие необратимо."
        ),
        "rows": [[("✅ Да, удалить", "del:yes"), ("❌ Нет", "menu:profile")]],
    }


def _show_resume_change(chat_id, message_id):
    """Инлайн-выбор резюме для активного профиля (правит сообщение на месте)."""
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        send_menu(chat_id, {"title": "❌ Нет активного профиля.",
                            "rows": [[("⬅️ Назад", "menu:profile")]]}, edit_message_id=message_id)
        return
    hh_account = profile.get("hh_account", "")
    if not (CONFIG_DIR / hh_account / "config.json").is_file():
        send_menu(chat_id, {
            "title": (f"📄 <b>Резюме</b>\nАккаунт <code>{html.escape(hh_account)}</code> не авторизован — "
                      "список резюме недоступен. Сначала «🔑 Авторизовать HH»."),
            "rows": [[("⬅️ Назад", "menu:profile")]],
        }, edit_message_id=message_id)
        return
    resumes = fetch_resumes_for_account(hh_account)
    if not resumes:
        send_menu(chat_id, {"title": "📄 <b>Резюме</b>\nУ аккаунта нет резюме на hh (или не удалось получить список).",
                            "rows": [[("⬅️ Назад", "menu:profile")]]}, edit_message_id=message_id)
        return
    RESUME_PICK["pid"] = pid
    RESUME_PICK["resumes"] = resumes
    current = profile.get("resume_id") or ""
    rows = []
    for idx, (rid, title) in enumerate(resumes):
        mark = "✅ " if rid == current else ""
        label = title if len(title) <= 38 else title[:37] + "…"
        rows.append([(f"{mark}{label}", f"setres:{idx}")])
    rows.append([(("✅ " if not current else "") + "↺ По умолчанию", "setres:none")])
    rows.append([("⬅️ Назад", "menu:profile")])
    send_menu(chat_id, {
        "title": f"📄 <b>Резюме профиля «{html.escape(profile.get('display_name') or pid)}»</b>\nТекущее — ✅:",
        "rows": rows,
    }, edit_message_id=message_id)


def build_menu_help():
    return {"title": cmd_help(), "rows": [[("⬅️ Назад", "menu:main")]]}


def menu_by_name(name):
    builders = {
        "main": build_menu_main,
        "view": build_menu_view,
        "ctl": build_menu_ctl,
        "profile": build_menu_profile,
        "ai": build_menu_ai,
        "ai_filter": build_menu_ai_filter,
        "filters": build_menu_filters,
        "f_exp": build_menu_f_exp,
        "f_sched": build_menu_f_sched,
        "f_order": build_menu_f_order,
        "f_format": build_menu_f_format,
        "f_banned": build_menu_f_banned,
        "ai_access": build_menu_ai_access,
        "ai_endpoint": build_menu_ai_endpoint,
        "switch": build_menu_switch,
        "del": build_menu_del,
        "help": build_menu_help,
    }
    builder = builders.get(name)
    return builder() if builder else None


# Ширина инлайн-кнопок в ряду делится поровну, поэтому длинная подпись рядом
# с короткой обрезается многоточием. Ряды с широкими подписями раскладываем
# по одной кнопке на строку — правило действует и на динамические меню.
MAX_PAIR_WIDTH = 15


def _label_width(label):
    """Примерная ширина подписи: эмодзи занимают две позиции, модификаторы — ноль."""
    width = 0
    for ch in label:
        code = ord(ch)
        if code in (0xFE0F, 0x200D) or 0x1F3FB <= code <= 0x1F3FF:
            continue
        width += 2 if (0x2190 <= code <= 0x2BFF or code >= 0x1F000) else 1
    return width


def _fit_rows(rows):
    result = []
    for row in rows:
        if len(row) > 1 and any(_label_width(label) > MAX_PAIR_WIDTH for label, _ in row):
            result.extend([[button] for button in row])
        else:
            result.append(row)
    return result


def send_menu(chat_id, menu, edit_message_id=None):
    """Шлёт (или редактирует на месте) сообщение с инлайн-меню."""
    if not menu:
        return
    if VK:
        return VK.send_menu(chat_id, menu["title"], _fit_rows(menu["rows"]),
                            edit_message_id=edit_message_id)
    keyboard = {
        "inline_keyboard": [
            [{"text": label, "callback_data": data} for label, data in row]
            for row in _fit_rows(menu["rows"])
        ]
    }
    params = {
        "chat_id": chat_id,
        "text": menu["title"],
        "parse_mode": "HTML",
        "disable_web_page_preview": "true",
        "reply_markup": json.dumps(keyboard),
    }
    if edit_message_id:
        params["message_id"] = edit_message_id
        method = "editMessageText"
    else:
        method = "sendMessage"
    try:
        api_call(method, **params)
    except Exception as e:
        print(f"send_menu failed: {e}", file=sys.stderr)


def run_command(chat_id, cmd):
    """Команды из инлайн-кнопок (callback 'cmd:<command>'). Возвращает текст."""
    handlers = {
        "/status": cmd_status,
        "/next": cmd_next,
        "/stats_today": lambda: cmd_stats(True),
        "/stats": lambda: cmd_stats(False),
        "/recent": cmd_recent,
        "/statuses": cmd_statuses,
        "/invites": cmd_invites,
        "/log": cmd_log,
        "/run": lambda: cmd_run(chat_id),
        "/pause": cmd_pause,
        "/resume": cmd_resume,
        "/cleanup": lambda: cmd_cleanup(chat_id),
        "/reply": lambda: cmd_reply_employers(chat_id),
        "/clear_skipped": lambda: cmd_clear_skipped(chat_id),
        "/backup": lambda: cmd_backup(chat_id),
        "/f_salary": lambda: cmd_filter_number_edit("/f_salary"),
        "/f_period": lambda: cmd_filter_number_edit("/f_period"),
        "/ai_filter_prompt": lambda: cmd_ai_prompt_edit("/ai_filter_prompt"),
        "/ai_message_prompt": lambda: cmd_ai_prompt_edit("/ai_message_prompt"),
        "/ai_system_prompt": lambda: cmd_ai_prompt_edit("/ai_system_prompt"),
        "/ai_rate": cmd_ai_rate_edit,
        "/ai_key": lambda: cmd_ai_config_edit("/ai_key"),
        "/ai_model": lambda: cmd_ai_config_edit("/ai_model"),
        "/ai_base_url": lambda: cmd_ai_config_edit("/ai_base_url"),
        "/ai_proxy": lambda: cmd_ai_config_edit("/ai_proxy"),
        "/letter": cmd_letter_show,
        "/letter_set": cmd_letter_set_prompt,
        "/search": cmd_search_show,
        "/search_set": cmd_search_set_prompt,
        "/profile_rename": cmd_profile_rename_prompt,
        "/area": cmd_area_prompt,
        "/profile_add": cmd_profile_add_start,
        "/auth": cmd_auth_start,
        "/profiles": cmd_profiles,
    }
    fn = handlers.get(cmd)
    return fn() if fn else None


def handle_callback(chat_id, message_id, data):
    """Нажатие инлайн-кнопки в сообщении-меню."""
    if VK and data.startswith("page:"):
        # Меню длиннее шести рядов VK не принимает — листаем страницами.
        try:
            VK.repaginate(chat_id, message_id, int(data[5:]))
        except ValueError:
            pass
        return
    if data == "menu:resume":
        _show_resume_change(chat_id, message_id)
        return
    if data.startswith("menu:"):
        send_menu(chat_id, menu_by_name(data[5:]), edit_message_id=message_id)
        return
    if data.startswith("switch:"):
        cmd_profile_switch(data[7:])
        send_menu(chat_id, build_menu_profile(), edit_message_id=message_id)
        return
    if data == "del:yes":
        reply = cmd_profile_remove_active()
        send(chat_id, reply)
        send_menu(chat_id, build_menu_main(), edit_message_id=message_id)
        return
    if data in ("ai:toggle", "ai:dry") or data.startswith("aifilter:"):
        pid, profile = profiles_lib.get_active_profile()
        if not profile:
            send_menu(chat_id, build_menu_profile(), edit_message_id=message_id)
            return
        ai = profiles_lib.get_ai(profile)
        try:
            if data == "ai:toggle":
                profiles_lib.update_ai(pid, enabled=not ai["enabled"])
            elif data == "ai:dry":
                profiles_lib.update_ai(pid, dry_run=not ai["dry_run"])
            else:
                mode = data.split(":", 1)[1]
                if mode not in profiles_lib.AI_FILTER_MODES:
                    mode = ""
                profiles_lib.update_ai(pid, filter=mode)
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка: {html.escape(str(e))}")
        send_menu(chat_id, build_menu_ai(), edit_message_id=message_id)
        return
    if data.startswith(("flt:", "fset:", "fmt:", "unban:", "ban:")):
        pid, profile = profiles_lib.get_active_profile()
        if not profile:
            send_menu(chat_id, build_menu_profile(), edit_message_id=message_id)
            return
        f = profiles_lib.get_filters(profile)
        try:
            if data.startswith("ban:"):
                send(chat_id, cmd_ban_employer(chat_id, data[4:]))
                return
            if data.startswith("flt:"):
                field = data[4:]
                profiles_lib.update_filters(pid, **{field: not f[field]})
            elif data.startswith("fset:"):
                _, field, value = data.split(":", 2)
                profiles_lib.update_filters(pid, **{field: value})
            elif data.startswith("fmt:"):
                value = data[4:]
                formats = list(f["work_format"])
                formats.remove(value) if value in formats else formats.append(value)
                profiles_lib.update_filters(pid, work_format=formats)
            else:
                target = data[6:]
                if target == "all":
                    profiles_lib.update_filters(pid, excluded_employer_ids=[])
                else:
                    profiles_lib.update_filters(
                        pid, excluded_employer_ids=[e for e in f["excluded_employer_ids"] if e != target])
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка: {html.escape(str(e))}")
        if data.startswith("fmt:"):
            send_menu(chat_id, build_menu_f_format(), edit_message_id=message_id)
        elif data.startswith("unban:"):
            send_menu(chat_id, build_menu_f_banned(), edit_message_id=message_id)
        elif data.startswith("fset:"):
            send_menu(chat_id, build_menu_filters(), edit_message_id=message_id)
        else:
            send_menu(chat_id, build_menu_filters(), edit_message_id=message_id)
        return
    if data == "aicfg:captcha" or data.startswith("aiurl:"):
        _, profile = profiles_lib.get_active_profile()
        if not profile:
            send_menu(chat_id, build_menu_profile(), edit_message_id=message_id)
            return
        account = profile.get("hh_account", "main")
        cfg = read_ai_config(account)
        if data == "aicfg:captcha":
            if cfg["captcha"]:
                hh_config_unset(account, f"{AI_SECTION_CAPTCHA}.api_key")
            elif not cfg["api_key"]:
                send(chat_id, "⚠️ Сначала задай ключ — включать капчу нечем.")
            else:
                for field in ("api_key", "base_url", "model"):
                    if cfg[field]:
                        hh_config_set(account, f"{AI_SECTION_CAPTCHA}.{field}", cfg[field])
        else:
            try:
                _, url = AI_ENDPOINTS[int(data.split(":", 1)[1])]
            except (ValueError, IndexError):
                url = ""
            if url:
                sections = [AI_SECTION_COVER, AI_SECTION_FILTER]
                if cfg["captcha"]:
                    sections.append(AI_SECTION_CAPTCHA)
                errors = ai_config_apply(account, "base_url", url, sections)
                if errors:
                    send(chat_id, "⚠️ " + html.escape("; ".join(errors)))
        send_menu(chat_id, build_menu_ai_access(), edit_message_id=message_id)
        return
    if data.startswith("setres:"):
        pid = RESUME_PICK.get("pid")
        resumes = RESUME_PICK.get("resumes") or []
        if not pid:
            send_menu(chat_id, build_menu_profile(), edit_message_id=message_id)
            return
        sel = data[7:]
        if sel == "none":
            resume_id = ""
        else:
            try:
                idx = int(sel)
                resume_id = resumes[idx][0] if 0 <= idx < len(resumes) else ""
            except ValueError:
                resume_id = ""
        try:
            profiles_lib.update_profile(pid, resume_id=resume_id)
        except Exception as e:
            send(chat_id, f"⚠️ Ошибка: {html.escape(str(e))}")
        RESUME_PICK["pid"] = None
        RESUME_PICK["resumes"] = None
        send_menu(chat_id, build_menu_profile(), edit_message_id=message_id)
        return
    if data.startswith("cmd:"):
        reply = run_command(chat_id, data[4:])
        if reply is not None:
            send(chat_id, reply)
        return


# =================== Нижняя панель и обработка сообщений ===================

def handle_message(chat_id, text, user_msg_id):
    """Входящее текстовое сообщение: нижние кнопки, ввод текста, команды."""
    t = (text or "").strip()

    # Идёт авторизация — текст уходит в утилиту (кроме /cancel)
    with AUTH_LOCK:
        auth_active = AUTH_DIALOG["active"]
    if auth_active:
        if t == "/cancel":
            send(chat_id, cmd_cancel())
            return
        handle_auth_input(t)
        return

    # /cancel — отмена текущего ожидания ввода
    if t == "/cancel":
        send(chat_id, cmd_cancel())
        return

    # /start — поставить нижнюю панель
    if t == "/start":
        PENDING["action"] = None
        PENDING["data"] = None
        tg_delete(chat_id, user_msg_id)
        set_panel(chat_id, "👋 Панель команд внизу. «🎛 Меню» — полное меню.")
        return

    # /menu — открыть инлайн-меню сообщением
    if t == "/menu":
        tg_delete(chat_id, user_msg_id)
        send_menu(chat_id, build_menu_main())
        return

    # Нижние 5 кнопок (работают и во время ожидания ввода — отменяют ввод)
    if t in QUICK_LABELS:
        tg_delete(chat_id, user_msg_id)
        if PENDING["action"]:
            PENDING["action"] = None
            PENDING["data"] = None
        if t == "🎛 Меню":
            send_menu(chat_id, build_menu_main())
        elif t == "▶️ Старт":
            reply = cmd_run(chat_id)
            if reply is not None:
                send(chat_id, reply)
        elif t == "⏸ Пауза":
            send(chat_id, cmd_pause())
        elif t == "▶️ Возобновить":
            send(chat_id, cmd_resume())
        elif t == "⏰ Лимит":
            send(chat_id, cmd_next())
        return

    # Ожидание текстового ввода
    if PENDING["action"]:
        action = PENDING["action"]
        if action == "letter_set":
            reply = cmd_letter_save(t)
        elif action == "search_set":
            reply = cmd_search_save(t)
        elif action == "profile_rename":
            reply = cmd_profile_rename_save(t)
        elif action == "area_set":
            reply = cmd_area_save(t)
        elif action.startswith("flt_num:"):
            reply = cmd_filter_number_save(action.split(":", 1)[1], t)
        elif action.startswith("aicfg:"):
            field = action.split(":", 1)[1]
            if field == "api_key":
                tg_delete(chat_id, user_msg_id)
            reply = cmd_ai_config_save(field, t)
        elif action.startswith("ai_set:"):
            reply = cmd_ai_save(action.split(":", 1)[1], t)
        elif action.startswith("profile_add:"):
            reply = cmd_profile_add_step(t)
        else:
            reply = None
        if reply is not None:
            send(chat_id, reply)
        return

    # Любой другой текст
    send(chat_id, "Пользуйся кнопками внизу. «🎛 Меню» или /menu — меню.")


def clear_bot_commands():
    """Убирает slash-меню Telegram (пустой список команд)."""
    try:
        data = urllib.parse.urlencode({"commands": json.dumps([])}).encode()
        urllib.request.urlopen(
            f"{API}/setMyCommands",
            data=data, timeout=15
        ).read()
        print("Cleared bot commands (slash menu removed)", flush=True)
    except Exception as e:
        print(f"setMyCommands clear failed: {e}", file=sys.stderr)


def cleanup_stale_auth():
    """При старте бота убираем висящие auth-файлы (если бот рестартанул
    во время диалога авторизации)."""
    for f in (AUTH_REQ, AUTH_OUT, AUTH_IN, AUTH_STATUS, AUTH_CAPTCHA):
        try:
            if f.exists():
                f.unlink()
        except Exception:
            pass
    # Просим helper отменить процесс если он висит
    try:
        AUTH_CANCEL.touch()
    except Exception:
        pass
    with AUTH_LOCK:
        AUTH_DIALOG["active"] = False
        AUTH_DIALOG["profile_id"] = None
        AUTH_DIALOG["hh_account"] = None


def vk_loop():
    """Тот же обработчик команд, но события приходят из VK Long Poll."""
    while True:
        try:
            for event in VK.poll():
                if VK.peer_id and event["chat_id"] != VK.peer_id:
                    continue
                if event["type"] == "callback":
                    VK.answer_callback(event["event_id"], event["user_id"], event["chat_id"])
                    try:
                        handle_callback(event["chat_id"], event["message_id"], event["data"])
                    except Exception as e:
                        import traceback
                        traceback.print_exc()
                        send(event["chat_id"], f"⚠️ Ошибка: {e}")
                elif event["text"]:
                    try:
                        handle_message(event["chat_id"], event["text"], event["message_id"])
                    except Exception as e:
                        import traceback
                        traceback.print_exc()
                        send(event["chat_id"], f"⚠️ Ошибка: {e}")
        except Exception as e:
            print(f"VK poll error: {e}", file=sys.stderr)
            time.sleep(5)


def main():
    print(f"Bot started. Paused: {is_paused()}", flush=True)

    cleanup_stale_auth()
    if not VK:
        clear_bot_commands()

    # Каждому профилю — своё письмо (идемпотентно)
    try:
        profiles_lib.migrate_unique_letters()
    except Exception as e:
        print(f"letter migration failed: {e}", file=sys.stderr)

    # Ставим нижнюю панель при старте
    try:
        set_panel(TG_CHAT, "🤖 Бот запущен. Панель команд внизу.")
    except Exception as e:
        print(f"initial panel failed: {e}", file=sys.stderr)

    if VK:
        return vk_loop()

    offset = None
    while True:
        try:
            params = {"timeout": 50, "allowed_updates": json.dumps(["message", "callback_query"])}
            if offset is not None:
                params["offset"] = offset
            resp = api_call("getUpdates", **params)
            for upd in resp.get("result", []):
                offset = upd["update_id"] + 1

                cb = upd.get("callback_query")
                if cb:
                    cb_chat = str(((cb.get("message") or {}).get("chat") or {}).get("id", ""))
                    if cb_chat != TG_CHAT:
                        continue
                    cb_data = cb.get("data") or ""
                    cb_msg_id = (cb.get("message") or {}).get("message_id")
                    try:
                        api_call("answerCallbackQuery", callback_query_id=cb["id"])
                    except Exception:
                        pass
                    try:
                        handle_callback(cb_chat, cb_msg_id, cb_data)
                    except Exception as e:
                        import traceback
                        traceback.print_exc()
                        send(cb_chat, f"⚠️ Ошибка: {html.escape(str(e))}")
                    continue

                msg = upd.get("message") or {}
                chat_id = str((msg.get("chat") or {}).get("id", ""))
                if chat_id != TG_CHAT:
                    continue
                text = msg.get("text") or ""
                if not text:
                    continue
                msg_id = msg.get("message_id")
                try:
                    handle_message(chat_id, text, msg_id)
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    send(chat_id, f"⚠️ Ошибка: {html.escape(str(e))}")
        except Exception as e:
            print(f"poll error: {e}", file=sys.stderr)
            time.sleep(5)


if __name__ == "__main__":
    main()
