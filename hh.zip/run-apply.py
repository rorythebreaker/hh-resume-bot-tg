#!/usr/bin/env python3
"""Builds apply-vacancies command from the active profile and execs it.

Doing this in Python (not bash) avoids word-splitting problems with
search queries that contain spaces, quotes, OR/NOT operators and parens.
"""
import os
import sys

sys.path.insert(0, "/app")
import profiles_lib

LETTERS_DIR = "/app/letters"


def main():
    pid, profile = profiles_lib.get_active_profile()
    if not profile:
        print("ERROR: no active profile", file=sys.stderr)
        return 1

    hh_account = profile.get("hh_account", "main")
    search = profile.get("search", "")
    letter = profile.get("letter", "letter_default.txt")
    area = str(profile.get("area", 113))
    excluded = profile.get("excluded_filter", "")
    resume_id = (profile.get("resume_id") or "").strip()

    display = profile.get("display_name") or pid
    print(f"Profile: {display} (HH account: {hh_account})")
    print(f"Search: {search}")
    print(f"Letter: {letter}, Area: {area}")

    letter_path = os.path.join(LETTERS_DIR, os.path.basename(letter))
    if not os.path.isfile(letter_path):
        print(f"ERROR: letter file not found: {letter_path}", file=sys.stderr)
        return 1

    if not search.strip():
        print("ERROR: empty search query", file=sys.stderr)
        return 1

    # Каждый аргумент — отдельный элемент списка, никакого word-splitting.
    args = [
        "hh-applicant-tool",
        "--profile", hh_account,
        "apply-vacancies",
        "-L", letter_path,
        "--force-message",
        "--search", search,
        "--area", area,
    ]

    if resume_id:
        args.extend(["--resume-id", resume_id])

    # excluded_filter: утилита принимает ОДНУ строку через запятую
    # (как в исходной рабочей версии: --excluded-filter "a,b,c").
    excluded = (excluded or "").strip()
    if excluded:
        args.extend(["--excluded-filter", excluded])

    # --- Фильтры поиска и поведение рассылки ---------------------------
    f = profiles_lib.get_filters(profile)

    if f["experience"]:
        args.extend(["--experience", f["experience"]])
    if f["schedule"]:
        args.extend(["--schedule", f["schedule"]])
    if f["work_format"]:
        args.append("--work-format")
        args.extend(f["work_format"])
    if f["salary"]:
        args.extend(["--salary", str(f["salary"])])
    if f["only_with_salary"]:
        args.append("--only-with-salary")
    if f["period"]:
        args.extend(["--period", str(f["period"])])
    if f["order_by"]:
        args.extend(["--order-by", f["order_by"]])
    if f["skip_tests"]:
        args.append("--skip-tests")
    if f["send_email"]:
        args.append("--send-email")
    if f["excluded_employer_ids"]:
        args.append("--excluded-employer-id")
        args.extend(f["excluded_employer_ids"])

    # --- AI (1.8.26) ---------------------------------------------------
    ai = profiles_lib.get_ai(profile)

    if ai["enabled"]:
        args.append("--use-ai")
        if ai["system_prompt"].strip():
            args.extend(["--system-prompt", ai["system_prompt"].strip()])
        if ai["message_prompt"].strip():
            args.extend(["--message-prompt", ai["message_prompt"].strip()])

    if ai["filter"]:
        # Режим custom без промпта утилита примет, но фильтровать будет нечем,
        # поэтому падаем до отправки первого отклика, а не после.
        if ai["filter"] == "custom" and not ai["filter_prompt"].strip():
            print("ERROR: ai.filter=custom requires ai.filter_prompt", file=sys.stderr)
            return 1
        args.extend(["--ai-filter", ai["filter"]])
        if ai["filter"] == "custom":
            args.extend(["--ai-filter-prompt", ai["filter_prompt"].strip()])

    if (ai["enabled"] or ai["filter"]) and ai["rate_limit"] != 40:
        args.extend(["--ai-rate-limit", str(ai["rate_limit"])])

    if ai["dry_run"]:
        args.append("--dry-run")

    if ai["enabled"] or ai["filter"]:
        print(f"AI: messages={ai['enabled']}, filter={ai['filter'] or 'off'}, "
              f"rate_limit={ai['rate_limit']}, dry_run={ai['dry_run']}")

    print(f"Exec: {args}", flush=True)
    # Заменяем текущий процесс утилитой (как exec в bash)
    os.execvp(args[0], args)


if __name__ == "__main__":
    sys.exit(main())
