#!/bin/bash
# Runs an hh-applicant-tool subcommand for every authorized hh-account.
# Authorized = a token file exists at $CONFIG_DIR/<account>/config.json.
# Usage: hh-run-all.sh <subcommand> [args...]   e.g. refresh-token | update-resumes | clear-negotiations -d
set -u

CONFIG_DIR="${CONFIG_DIR:-/app/config}"

accounts=$(python3 -c "import sys; sys.path.insert(0, '/app'); import profiles_lib; print('\n'.join(profiles_lib.get_hh_accounts()))")

for acc in $accounts; do
    if [ -f "$CONFIG_DIR/$acc/config.json" ]; then
        hh-applicant-tool --profile "$acc" "$@"
    else
        echo "[hh-run-all] skip $acc (no token)"
    fi
done
