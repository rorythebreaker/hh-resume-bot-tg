#!/usr/bin/env python3
"""Patch installed hh_applicant_tool so that, on captcha:
1) the <img> is fully loaded before the screenshot (headless screenshot of a
   not-yet-loaded image is blank white);
2) the raw screenshot PNG is saved to $CONFIG_DIR/.auth_captcha.png so the
   Telegram bot can send it directly, without parsing terminal-graphics output.
Idempotent; never fails the build (exits 0 on any issue)."""
import sys

try:
    from hh_applicant_tool.operations import authorize
    path = authorize.__file__
except Exception as e:
    print(f"patch_captcha: cannot import authorize.py: {e}")
    sys.exit(0)

TARGET = "        img_bytes = await captcha_element.screenshot()"
WAIT_BEFORE = (
    "        try:\n"
    "            await page.wait_for_function(\n"
    "                \"sel => { const i = document.querySelector(sel);"
    " return !!(i && i.complete && i.naturalWidth > 0); }\",\n"
    "                arg=self.SEL_CAPTCHA_IMAGE,\n"
    "                timeout=self.selector_timeout,\n"
    "            )\n"
    "        except Exception:\n"
    "            pass\n"
)
SAVE_AFTER = (
    "        try:\n"
    "            import os as _os\n"
    "            _cap = _os.environ.get('CONFIG_DIR', '/app/config')"
    " + '/.auth_captcha.png'\n"
    "            with open(_cap + '.tmp', 'wb') as _f:\n"
    "                _f.write(img_bytes)\n"
    "            _os.replace(_cap + '.tmp', _cap)\n"
    "        except Exception:\n"
    "            pass\n"
)

try:
    src = open(path, encoding="utf-8").read()
except Exception as e:
    print(f"patch_captcha: cannot read {path}: {e}")
    sys.exit(0)

if ".auth_captcha.png" in src:
    print("patch_captcha: already patched")
    sys.exit(0)
if TARGET not in src:
    print("patch_captcha: target line not found, skipping (version changed?)")
    sys.exit(0)

src = src.replace(TARGET, WAIT_BEFORE + TARGET + "\n" + SAVE_AFTER, 1)
try:
    open(path, "w", encoding="utf-8").write(src)
    print(f"patch_captcha: patched {path}")
except Exception as e:
    print(f"patch_captcha: cannot write {path}: {e}")
sys.exit(0)
